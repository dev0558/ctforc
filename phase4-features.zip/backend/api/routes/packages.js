const { Router } = require("express");
const fs = require("fs");
const path = require("path");
const config = require("../../config");

const router = Router();

/**
 * GET /api/packages/:jobId/specialist
 * Download the specialist (admin) package ZIP.
 */
router.get("/:jobId/specialist", (req, res) => {
  try {
    const packageDir = path.join(config.storage.basePath, "packages", req.params.jobId);

    if (!fs.existsSync(packageDir)) {
      return res.status(404).json({ error: "Package not found. Challenge may not be approved yet." });
    }

    const files = fs.readdirSync(packageDir).filter((f) => f.includes("specialist") && f.endsWith(".zip"));
    if (files.length === 0) {
      return res.status(404).json({ error: "Specialist package not found" });
    }

    const zipPath = path.join(packageDir, files[0]);
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${files[0]}"`);
    res.setHeader("Content-Length", fs.statSync(zipPath).size);
    fs.createReadStream(zipPath).pipe(res);
  } catch (err) {
    console.error("[Packages] Download error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/packages/:jobId/participant
 * Download the participant package ZIP.
 */
router.get("/:jobId/participant", (req, res) => {
  try {
    const packageDir = path.join(config.storage.basePath, "packages", req.params.jobId);

    if (!fs.existsSync(packageDir)) {
      return res.status(404).json({ error: "Package not found" });
    }

    const files = fs.readdirSync(packageDir).filter((f) => f.includes("participant") && f.endsWith(".zip"));
    if (files.length === 0) {
      return res.status(404).json({ error: "Participant package not found" });
    }

    const zipPath = path.join(packageDir, files[0]);
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${files[0]}"`);
    res.setHeader("Content-Length", fs.statSync(zipPath).size);
    fs.createReadStream(zipPath).pipe(res);
  } catch (err) {
    console.error("[Packages] Download error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/packages/:jobId/info
 * Get package metadata (sizes, filenames) without downloading.
 */
router.get("/:jobId/info", (req, res) => {
  try {
    const packageDir = path.join(config.storage.basePath, "packages", req.params.jobId);

    if (!fs.existsSync(packageDir)) {
      return res.status(404).json({ exists: false });
    }

    const allFiles = fs.readdirSync(packageDir);
    const specialist = allFiles.find((f) => f.includes("specialist") && f.endsWith(".zip"));
    const participant = allFiles.find((f) => f.includes("participant") && f.endsWith(".zip"));

    res.json({
      exists: true,
      specialist: specialist
        ? { filename: specialist, size: fs.statSync(path.join(packageDir, specialist)).size }
        : null,
      participant: participant
        ? { filename: participant, size: fs.statSync(path.join(packageDir, participant)).size }
        : null,
    });
  } catch (err) {
    console.error("[Packages] Info error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
