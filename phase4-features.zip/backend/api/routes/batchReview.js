const { Router } = require("express");
const { z } = require("zod");

const router = Router();

const batchReviewSchema = z.object({
  jobIds: z.array(z.string().uuid()).min(1).max(50),
  stage: z.enum(["spec", "build"]),
  action: z.enum(["approve", "reject"]),
  notes: z.string().optional(),
});

/**
 * POST /api/jobs/batch-review
 * Approve or reject multiple jobs at once.
 */
router.post("/batch-review", async (req, res) => {
  try {
    const parsed = batchReviewSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Validation failed", details: parsed.error.issues });
    }

    const { jobIds, stage, action, notes } = parsed.data;

    // Determine the expected status based on stage
    const expectedStatus = stage === "spec" ? "pending_spec_review" : "pending_build_review";

    // Dynamic import to avoid circular deps
    const db = require("../../db/client");
    const { builderQueue } = require("../../queue");

    const results = [];
    let processed = 0;
    let skipped = 0;

    for (const jobId of jobIds) {
      const job = db.jobs.findById(jobId);

      if (!job) {
        results.push({ jobId, success: false, error: "Job not found" });
        skipped++;
        continue;
      }

      if (job.status !== expectedStatus) {
        results.push({ jobId, success: false, error: `Job is ${job.status}, expected ${expectedStatus}` });
        skipped++;
        continue;
      }

      // Create review record
      db.reviews.create({ jobId, stage, action, notes: notes || null });

      if (action === "approve") {
        if (stage === "spec") {
          db.jobs.update(jobId, { status: "spec_approved" });
          // Queue for building
          await builderQueue.add(`build-${jobId}`, { jobId }, {
            attempts: 2,
            backoff: { type: "exponential", delay: 30000 },
          });
          results.push({ jobId, success: true, status: "spec_approved" });
        } else {
          db.jobs.update(jobId, { status: "ready", completed_at: new Date().toISOString() });
          // TODO: trigger packager here
          results.push({ jobId, success: true, status: "ready" });
        }
      } else {
        // Reject
        const newStatus = stage === "spec" ? "reworking_spec" : "reworking_build";
        const revision = stage === "spec" ? (job.spec_revision || 1) : (job.build_revision || 1);
        const maxRevisions = 3;

        if (notes && notes.trim() && revision < maxRevisions) {
          db.jobs.update(jobId, { status: newStatus });
          // Queue for rework (if rework cycle is implemented)
          results.push({ jobId, success: true, status: newStatus, message: "Queued for AI rework" });
        } else {
          db.jobs.update(jobId, { status: "rejected_final" });
          results.push({ jobId, success: true, status: "rejected_final" });
        }
      }

      processed++;
    }

    res.json({
      processed,
      skipped,
      total: jobIds.length,
      results,
    });
  } catch (err) {
    console.error("[BatchReview] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
