const fs = require("fs");
const path = require("path");
const archiver = require("archiver");
const { generateDungeonConfig } = require("./dungeonExport");

// Files that NEVER go in participant package
const SPECIALIST_ONLY_PATTERNS = [
  "writeup/",
  "solve",
  "exploit",
  "hints.json",
  "anti_ai_manifest",
  "dungeon_config",
  "Dockerfile",
  "docker-compose",
  "Makefile",
  ".env",
  "flag.txt",
  "init.sql",
];

// Files the participant gets per category
const PARTICIPANT_FILES = {
  web: [],  // Web participants get a URL, not files
  forensics: ["source/generate_artifacts.py:output"],  // They get the GENERATED artifacts, not the generator
  crypto: ["source/ciphertext.txt", "source/ciphertext.bin", "source/encrypt.py", "source/public_key.pem"],
  osint: ["source/generate_breadcrumbs.py:output"],
  network: ["source/generate_capture.py:output"],
  pwn: ["source/vuln"],  // Compiled binary only, not source
};

/**
 * Create both specialist and participant packages.
 */
async function createPackages(jobId, spec, challengeDir, testResults, storagePath) {
  const packageDir = path.join(storagePath, "packages", jobId);
  if (!fs.existsSync(packageDir)) fs.mkdirSync(packageDir, { recursive: true });

  const safeName = sanitizeName(spec.challengeName || "challenge");

  // Generate DUNGEON config
  const dungeonConfig = generateDungeonConfig(spec, testResults);
  const dungeonPath = path.join(challengeDir, "config", "dungeon_config.json");
  if (!fs.existsSync(path.dirname(dungeonPath))) fs.mkdirSync(path.dirname(dungeonPath), { recursive: true });
  fs.writeFileSync(dungeonPath, JSON.stringify(dungeonConfig, null, 2));

  // Generate specialist README
  const specialistReadme = generateSpecialistReadme(spec, testResults);
  fs.writeFileSync(path.join(challengeDir, "specialist_readme.md"), specialistReadme);

  // Generate participant README
  const participantReadme = generateParticipantReadme(spec);

  // Create specialist package (everything)
  const specialistPath = path.join(packageDir, `${safeName}_specialist.zip`);
  await createZip(challengeDir, specialistPath, () => true);

  // Create participant package (filtered)
  const participantPath = path.join(packageDir, `${safeName}_participant.zip`);
  await createParticipantZip(spec, challengeDir, participantPath, participantReadme);

  const specialistSize = fs.statSync(specialistPath).size;
  const participantSize = fs.statSync(participantPath).size;

  return {
    specialistPath,
    participantPath,
    specialistSize,
    participantSize,
    specialistFilename: `${safeName}_specialist.zip`,
    participantFilename: `${safeName}_participant.zip`,
  };
}

/**
 * Create a ZIP with all files from a directory.
 */
function createZip(sourceDir, outputPath, filter) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outputPath);
    const archive = archiver("zip", { zlib: { level: 9 } });

    output.on("close", resolve);
    archive.on("error", reject);
    archive.pipe(output);

    addDirToArchive(archive, sourceDir, sourceDir, filter);
    archive.finalize();
  });
}

/**
 * Create participant ZIP with only safe files.
 */
function createParticipantZip(spec, challengeDir, outputPath, readmeContent) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outputPath);
    const archive = archiver("zip", { zlib: { level: 9 } });

    output.on("close", resolve);
    archive.on("error", reject);
    archive.pipe(output);

    // Add participant README
    archive.append(readmeContent, { name: "README.md" });

    // Add challenge description
    const descPath = path.join(challengeDir, "config", "challenge.json");
    if (fs.existsSync(descPath)) {
      try {
        const config = JSON.parse(fs.readFileSync(descPath, "utf-8"));
        // Strip sensitive fields
        delete config.flag;
        delete config.honeypotFlag;
        delete config._debug_flag;
        delete config._ai_hint;
        archive.append(JSON.stringify(config, null, 2), { name: "challenge.json" });
      } catch {}
    }

    // Add category-specific participant files
    const category = spec.category || "web";
    const allowedPatterns = PARTICIPANT_FILES[category] || [];

    for (const pattern of allowedPatterns) {
      if (pattern.endsWith(":output")) {
        // This means we want the OUTPUT of the generator, not the generator itself
        // Look for generated artifact files in the challenge dir
        const artifactsDir = path.join(challengeDir, "artifacts");
        if (fs.existsSync(artifactsDir)) {
          addDirToArchive(archive, artifactsDir, artifactsDir, () => true, "artifacts/");
        }
      } else {
        const filePath = path.join(challengeDir, pattern);
        if (fs.existsSync(filePath)) {
          // Scrub the file content to remove any flags
          let content = fs.readFileSync(filePath, "utf-8");
          if (spec.flag) content = content.replace(new RegExp(escapeRegex(spec.flag), "g"), "REDACTED");
          if (spec.honeypotFlag) content = content.replace(new RegExp(escapeRegex(spec.honeypotFlag), "g"), "REDACTED");
          archive.append(content, { name: path.basename(pattern) });
        }
      }
    }

    archive.finalize();
  });
}

function addDirToArchive(archive, dir, baseDir, filter, prefix = "") {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relativePath = prefix + path.relative(baseDir, fullPath);
    if (entry.isDirectory()) {
      addDirToArchive(archive, fullPath, baseDir, filter, prefix);
    } else if (filter(relativePath)) {
      archive.file(fullPath, { name: relativePath });
    }
  }
}

function generateSpecialistReadme(spec, testResults) {
  const lines = [
    `# ${spec.challengeName} : Specialist Guide`,
    ``,
    `**Category:** ${spec.category} | **Difficulty:** ${spec.difficulty} | **Points:** ${spec.points}`,
    ``,
    `## Flag`,
    `\`${spec.flag}\``,
    ``,
    `## Honeypot Flag (decoy)`,
    `\`${spec.honeypotFlag}\``,
    ``,
    `## Deployment`,
  ];

  if (["web", "pwn"].includes(spec.category)) {
    lines.push(`\`\`\`bash`);
    lines.push(`cd source/`);
    lines.push(`docker build -t ${sanitizeName(spec.challengeName)} .`);
    lines.push(`docker run -d -p 80:80 --name ${sanitizeName(spec.challengeName)} ${sanitizeName(spec.challengeName)}`);
    lines.push(`\`\`\``);
  } else {
    lines.push(`\`\`\`bash`);
    lines.push(`cd source/`);
    lines.push(`pip install -r requirements.txt`);
    lines.push(`python3 generate_artifacts.py`);
    lines.push(`# Distribute the generated files in artifacts/ to participants`);
    lines.push(`\`\`\``);
  }

  lines.push(``, `## Exploit Path`);
  (spec.exploitPath || []).forEach((step, i) => lines.push(`${i + 1}. ${step}`));

  lines.push(``, `## Anti-AI Countermeasures`);
  (spec.antiAiCountermeasures || []).forEach((m) => lines.push(`- ${m}`));

  if (testResults) {
    lines.push(``, `## Test Results`);
    lines.push(`- Overall: ${testResults.overallPass ? "PASS" : "FAIL"}`);
    if (testResults.dockerBuild) lines.push(`- Docker build: ${testResults.dockerBuild.success ? "pass" : "fail"}`);
    if (testResults.solveScript) lines.push(`- Solve script: ${testResults.solveScript.success ? "pass" : "fail"}`);
    lines.push(`- Flag verified: ${testResults.flagVerification?.realFlagFound ? "yes" : "no"}`);
  }

  lines.push(``, `## DUNGEON Configuration`, `Import \`config/dungeon_config.json\` into the DUNGEON platform to auto-fill the challenge form.`);

  return lines.join("\n");
}

function generateParticipantReadme(spec) {
  return [
    `# ${spec.challengeName}`,
    ``,
    `**Category:** ${spec.category}`,
    `**Difficulty:** ${spec.difficulty}`,
    `**Points:** ${spec.points}`,
    ``,
    `## Briefing`,
    ``,
    spec.narrative || "No description available.",
    ``,
    `## Rules`,
    `- Flag format: Exploit3rs{...}`,
    `- Do not share flags with other participants`,
    `- Use any tools at your disposal`,
    ``,
    `Good luck!`,
  ].join("\n");
}

function sanitizeName(name) {
  return (name || "challenge").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "").substring(0, 50);
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

module.exports = { createPackages };
