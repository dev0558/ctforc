module.exports = {
  id: "web",
  name: "Web Exploitation",
  description: "Challenges based on web application vulnerabilities including SQLi, XSS, SSTI, SSRF, command injection, auth bypass, and more",
  icon: "globe",
  color: "#378ADD",
  defaultTechStack: ["Python", "Flask", "Docker", "SQLite"],
  artifactTypes: ["Dockerfile", "docker-compose.yml", "Application source", "Exploit script", "Writeup"],
  difficultyWeights: { easy: 100, medium: 300, hard: 500 },
  supportsDocker: true,
  formFields: [
    { id: "cveId", label: "CVE ID (optional)", type: "text", placeholder: "CVE-2023-22527", required: false },
    { id: "targetStack", label: "Target tech stack", type: "select", options: ["Flask (Python)", "Express (Node.js)", "PHP/Laravel", "Java/Spring", "Django", "Ruby on Rails", "ASP.NET"], required: true },
    { id: "vulnType", label: "Vulnerability type", type: "select", options: ["SQL Injection", "Cross-Site Scripting (XSS)", "Server-Side Template Injection (SSTI)", "Server-Side Request Forgery (SSRF)", "OS Command Injection", "Path Traversal", "Authentication Bypass", "IDOR", "Insecure Deserialization", "XML External Entity (XXE)", "Prototype Pollution", "File Upload", "Other"], required: true },
    { id: "hasDatabase", label: "Requires database", type: "toggle", default: true },
    { id: "hasAuth", label: "Requires authentication flow", type: "toggle", default: false },
  ],
};
