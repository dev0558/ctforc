module.exports = {
  id: "forensics",
  name: "Forensics",
  description: "Challenges involving PCAP analysis, log analysis, memory forensics, disk imaging, steganography, and file carving",
  icon: "search",
  color: "#1D9E75",
  defaultTechStack: ["Python", "Scapy", "Docker"],
  artifactTypes: ["PCAP generation script", "Log files", "Disk image spec", "Analysis writeup"],
  difficultyWeights: { easy: 100, medium: 300, hard: 500 },
  supportsDocker: false,
  formFields: [
    { id: "artifactType", label: "Primary artifact type", type: "select", options: ["PCAP (network capture)", "Log files (syslog/auth/web)", "Disk image", "Memory dump", "File carving", "Steganography"], required: true },
    { id: "evidenceDescription", label: "What evidence should players find", type: "textarea", placeholder: "DNS tunneling exfiltration via TXT record queries to suspicious domain...", required: true },
    { id: "toolHints", label: "Expected tools", type: "multiselect", options: ["Wireshark", "tshark", "Volatility", "Autopsy", "binwalk", "strings", "foremost", "exiftool", "steghide"], required: false },
    { id: "encodingChain", label: "Encoding chain (if any)", type: "text", placeholder: "base64 > hex > reversed", required: false },
  ],
};
