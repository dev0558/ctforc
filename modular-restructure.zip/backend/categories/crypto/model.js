module.exports = {
  id: "crypto",
  name: "Cryptography",
  description: "Challenges involving weak encryption, key leakage, protocol weaknesses, hash cracking, and mathematical attacks on cryptographic implementations",
  icon: "lock",
  color: "#7F77DD",
  defaultTechStack: ["Python", "PyCryptodome"],
  artifactTypes: ["Encryption script", "Ciphertext/encrypted file", "Solver script", "Math writeup"],
  difficultyWeights: { easy: 100, medium: 300, hard: 500 },
  supportsDocker: false,
  formFields: [
    { id: "algorithm", label: "Cryptographic algorithm", type: "select", options: ["RSA", "AES", "XOR", "Caesar/ROT", "Vigenere", "DES/3DES", "Diffie-Hellman", "Elliptic Curve", "Custom/homebrew"], required: true },
    { id: "weaknessType", label: "Weakness type", type: "select", options: ["Small public exponent", "Weak key generation", "Known plaintext", "Padding oracle", "ECB mode patterns", "Hardcoded key", "Broken PRNG", "Hash length extension", "Collision attack", "Other"], required: true },
    { id: "keySize", label: "Key size (bits)", type: "number", placeholder: "2048", required: false },
    { id: "providesSource", label: "Provide encryption source code to player", type: "toggle", default: true },
  ],
};
