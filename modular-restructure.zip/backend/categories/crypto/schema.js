const { z } = require("zod");

/**
 * Validation schema for crypto builder output.
 * Verifies that all required files exist in the generated package.
 */
const builderOutputSchema = z.object({
  files: z.array(z.string()).min(1, "Builder must produce at least one file"),
  tokenUsage: z.number().min(0),
  durationMs: z.number().min(0),
});

function validate(output) {
  const result = builderOutputSchema.safeParse(output);
  return {
    success: result.success,
    data: result.success ? result.data : null,
    errors: result.success ? [] : result.error.issues,
  };
}

module.exports = { builderOutputSchema, validate };
