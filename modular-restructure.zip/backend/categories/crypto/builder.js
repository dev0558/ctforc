const model = require("./model");

/**
 * Build challenge artifacts for this category.
 * Phase 1: mock implementation. Returns fake file manifest.
 * Phase 3: calls Claude API with prompt.md, validates output with schema.js
 */
async function build(approvedSpec) {
  console.log(`[${model.name} Builder] Building: ${approvedSpec.challengeName || "challenge"}`);

  // Simulate build time
  await new Promise((r) => setTimeout(r, 3000 + Math.random() * 2000));

  // Return mock artifacts based on category artifact types
  const files = model.artifactTypes.map((type, i) => {
    const filename = type.toLowerCase().replace(/[^a-z0-9]/g, "_");
    return `source/${filename}`;
  });
  files.push("writeup/WRITEUP.md", "writeup/hints.json", "config/challenge.json", "config/anti_ai_manifest.json");

  return {
    files,
    tokenUsage: 0,
    durationMs: 3000,
  };
}

module.exports = { build, model };
