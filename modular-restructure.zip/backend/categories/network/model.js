module.exports = {
  id: "network",
  name: "Network",
  description: "Challenges involving packet analysis, protocol exploitation, network reconnaissance, traffic analysis, and infrastructure attacks",
  icon: "wifi",
  color: "#1D9E75",
  defaultTechStack: ["Python", "Scapy", "Docker"],
  artifactTypes: ["PCAP captures", "Router/switch configs", "Network topology diagram", "Analysis writeup"],
  difficultyWeights: { easy: 100, medium: 300, hard: 500 },
  supportsDocker: true,
  formFields: [
    { id: "protocol", label: "Target protocol", type: "select", options: ["DNS", "HTTP/HTTPS", "TCP", "UDP", "ICMP", "ARP", "DHCP", "FTP", "SSH", "SMTP", "Custom"], required: true },
    { id: "captureType", label: "Capture type", type: "select", options: ["Live traffic PCAP", "Pre-built PCAP", "Network service", "Router config analysis"], required: true },
    { id: "topologyComplexity", label: "Topology complexity", type: "select", options: ["Single host", "Client-server", "Multi-hop network", "Full infrastructure"], required: true },
    { id: "requiresNetworking", label: "Requires active network interaction", type: "toggle", default: false },
  ],
};
