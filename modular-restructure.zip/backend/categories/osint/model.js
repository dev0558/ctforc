module.exports = {
  id: "osint",
  name: "OSINT",
  description: "Open Source Intelligence challenges involving social media reconnaissance, geolocation, metadata analysis, and digital breadcrumb trails",
  icon: "eye",
  color: "#D85A30",
  defaultTechStack: ["HTML", "Python", "ExifTool"],
  artifactTypes: ["Fake social profiles", "Images with EXIF metadata", "Breadcrumb trail documents", "Investigation writeup"],
  difficultyWeights: { easy: 100, medium: 300, hard: 500 },
  supportsDocker: false,
  formFields: [
    { id: "breadcrumbType", label: "Primary breadcrumb type", type: "select", options: ["Social media profiles", "Geolocation from images", "EXIF/metadata analysis", "Domain/WHOIS research", "Public records", "Mixed trail"], required: true },
    { id: "platforms", label: "Platforms involved", type: "multiselect", options: ["Twitter/X", "LinkedIn", "Instagram", "GitHub", "Reddit", "Personal website", "Google Maps", "WHOIS"], required: false },
    { id: "clueCount", label: "Number of clues in the trail", type: "number", placeholder: "5", required: true },
    { id: "requiresGeolocation", label: "Requires geolocation skills", type: "toggle", default: false },
  ],
};
