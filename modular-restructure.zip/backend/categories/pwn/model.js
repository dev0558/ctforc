module.exports = {
  id: "pwn",
  name: "Binary Exploitation (Pwn)",
  description: "Challenges involving buffer overflows, heap exploitation, format string vulnerabilities, ROP chains, and binary analysis",
  icon: "terminal",
  color: "#D4537E",
  defaultTechStack: ["C", "GCC", "GDB", "Docker"],
  artifactTypes: ["C source code", "Compiled binary (ELF)", "Makefile", "Exploit script", "Binary analysis writeup"],
  difficultyWeights: { easy: 100, medium: 300, hard: 500 },
  supportsDocker: true,
  formFields: [
    { id: "vulnType", label: "Vulnerability type", type: "select", options: ["Stack buffer overflow", "Heap overflow (use-after-free)", "Format string", "Integer overflow", "ROP chain", "Shellcode injection", "Return-to-libc", "Other"], required: true },
    { id: "architecture", label: "Target architecture", type: "select", options: ["x86 (32-bit)", "x86_64 (64-bit)", "ARM"], required: true },
    { id: "protections", label: "Binary protections enabled", type: "multiselect", options: ["NX (No Execute)", "Stack Canary", "ASLR", "PIE", "RELRO (Full)", "RELRO (Partial)", "None"], required: true },
    { id: "providesSource", label: "Provide source code to player", type: "toggle", default: false },
  ],
};
