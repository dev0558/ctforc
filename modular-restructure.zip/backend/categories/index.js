const web = require("./web/model");
const forensics = require("./forensics/model");
const crypto = require("./crypto/model");
const osint = require("./osint/model");
const network = require("./network/model");
const pwn = require("./pwn/model");

const categories = { web, forensics, crypto, osint, network, pwn };

function getCategory(id) {
  return categories[id] || null;
}

function getAllCategories() {
  return Object.values(categories);
}

function getCategoryIds() {
  return Object.keys(categories);
}

module.exports = { getCategory, getAllCategories, getCategoryIds, categories };
