const { Router } = require("express");
const { getAllCategories, getCategory } = require("../../categories");

const router = Router();

// GET /api/categories — list all categories with their models and form fields
router.get("/", (req, res) => {
  try {
    const categories = getAllCategories().map((cat) => ({
      id: cat.id,
      name: cat.name,
      description: cat.description,
      icon: cat.icon,
      color: cat.color,
      defaultTechStack: cat.defaultTechStack,
      artifactTypes: cat.artifactTypes,
      difficultyWeights: cat.difficultyWeights,
      supportsDocker: cat.supportsDocker,
      formFields: cat.formFields,
    }));

    res.json({ categories });
  } catch (err) {
    console.error("[Categories] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/categories/:id — single category detail
router.get("/:id", (req, res) => {
  try {
    const cat = getCategory(req.params.id);
    if (!cat) return res.status(404).json({ error: "Category not found" });
    res.json(cat);
  } catch (err) {
    console.error("[Categories] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
