# Modular Restructure — Ali's Feedback

## CONTEXT
Ali (CTO) reviewed the CTF Challenge Orchestrator and gave this feedback:
1. The project needs a modular approach for better organization and easier modification
2. Frontend: Dashboard + "Create a Challenge" section with category dropdown, where clicking a category leads to a category-specific UI
3. Backend: Each category should have a dedicated folder to represent a model in the codebase

This is a structural refactor. No new features, no new endpoints. We are reorganizing existing code into a modular pattern so that adding a new category means creating one new folder with self-contained files, not editing 5 different places.

## BACKEND CHANGES

### Create `backend/categories/` with one folder per category

Each category folder is self-contained. Everything the orchestrator needs to know about a category lives in that folder.

```
backend/categories/
  index.js              ← Category registry: exports all categories, used by router
  web/
    model.js            ← Category config: name, description, default tech stack, artifact types, difficulty weights
    builder.js          ← Builder agent: generates challenge code for this category
    prompt.md           ← Claude prompt template for the builder
    schema.js           ← Zod validation for builder output (what files must exist)
    formFields.json     ← Defines what extra fields the frontend form needs for this category
  forensics/
    model.js
    builder.js
    prompt.md
    schema.js
    formFields.json
  crypto/
    model.js
    builder.js
    prompt.md
    schema.js
    formFields.json
  osint/
    model.js
    builder.js
    prompt.md
    schema.js
    formFields.json
  network/
    model.js
    builder.js
    prompt.md
    schema.js
    formFields.json
  pwn/
    model.js
    builder.js
    prompt.md
    schema.js
    formFields.json
```

### What goes in each file

**model.js** — The category's identity card. Example for web:
```javascript
module.exports = {
  id: "web",
  name: "Web Exploitation",
  description: "Challenges based on web application vulnerabilities",
  icon: "globe",                    // Frontend uses this for display
  color: "#378ADD",                 // Category color on dashboard
  defaultTechStack: ["Python", "Flask", "Docker", "SQLite"],
  artifactTypes: ["Dockerfile", "app source", "exploit script", "writeup"],
  difficultyWeights: { easy: 100, medium: 300, hard: 500 },
  // Extra fields the Create form should show for this category
  formFields: [
    { id: "cveId", label: "CVE ID (optional)", type: "text", placeholder: "CVE-2023-22527" },
    { id: "targetStack", label: "Target tech stack", type: "select", options: ["Flask", "Express", "PHP/Laravel", "Java/Spring", "Django"] },
    { id: "vulnType", label: "Vulnerability type", type: "select", options: ["SQLi", "XSS", "SSTI", "SSRF", "Command Injection", "Path Traversal", "Auth Bypass", "IDOR", "Deserialization", "Other"] },
  ],
};
```

**builder.js** — The builder agent for this category. For Phase 1, this is still a mock. In Phase 3, it will call Claude with the category-specific prompt. The key point: each category's builder is isolated. Web builder knows how to make Dockerfiles and Flask apps. Forensics builder knows how to generate PCAP scripts. They don't share code.
```javascript
const model = require("./model");

async function build(approvedSpec) {
  // Phase 1: mock — return fake file manifest
  // Phase 3: call Claude with prompt.md, validate output with schema.js
  return {
    files: ["source/app.py", "source/Dockerfile", "writeup/WRITEUP.md"],
    tokenUsage: 0,
    durationMs: 0,
  };
}

module.exports = { build, model };
```

**prompt.md** — Claude prompt template specific to this category's builder. Web challenges need Docker + Flask prompts. Forensics needs PCAP generation prompts. Each is completely different.

**schema.js** — Zod schema validating the builder output. Web requires Dockerfile, app source, exploit script. Forensics requires PCAP generation script, analysis writeup. Different categories, different validation.

**formFields.json** — Defines what the frontend "Create a Challenge" form should show for this category. This drives the UI dynamically. When you click "Web" in the dropdown, the frontend reads this file (via an API endpoint) and renders the matching form fields. No hardcoded forms.

### New API endpoint
Add `GET /api/categories` that returns all registered categories with their model data and form fields. The frontend calls this once on load and uses it to build the category dropdown and dynamic forms.

```javascript
// backend/categories/index.js
const web = require("./web/model");
const forensics = require("./forensics/model");
const crypto = require("./crypto/model");
const osint = require("./osint/model");
const network = require("./network/model");
const pwn = require("./pwn/model");

const categories = { web, forensics, crypto, osint, network, pwn };

function getCategory(id) {
  return categories[id] || null;
}

function getAllCategories() {
  return Object.values(categories);
}

module.exports = { getCategory, getAllCategories, categories };
```

### Update the builder worker
The builder worker currently has hardcoded mock logic. Change it to:
1. Read the approved spec's category
2. Look up the category via `getCategory(spec.category)`
3. Call that category's `builder.build(spec)`
4. Validate the output against that category's `schema.js`

This means adding a new category is: create the folder, write the 5 files, register in index.js. Nothing else changes.

### Move existing builder/specialists/ content
Move `backend/builder/specialists/webBuilder.js` into `backend/categories/web/builder.js`. Delete the old specialists folder. The builder/index.js (category router) is replaced by the category registry pattern.

## FRONTEND CHANGES

### Add "Create a Challenge" page with category dropdown

**Route: /create**

This page has:
1. A dropdown showing all 6 categories (fetched from `GET /api/categories`)
2. When a category is selected, the form dynamically renders that category's fields
3. Common fields always shown: description, difficulty selector
4. Category-specific fields loaded from the model's formFields
5. Submit button that calls `POST /api/implement` with the idea mode payload including the extra fields

### Category-specific form components

Create `frontend/src/pages/categories/` with one form component per category:

```
frontend/src/pages/categories/
  WebForm.jsx         ← CVE input, tech stack picker, vuln type dropdown
  ForensicsForm.jsx   ← Artifact type (PCAP/disk/logs), evidence description
  CryptoForm.jsx      ← Algorithm picker, weakness type, key params
  OsintForm.jsx       ← Breadcrumb type, platforms, clue count
  NetworkForm.jsx     ← Protocol, capture type, topology
  PwnForm.jsx         ← Vuln type (BOF/heap/format), arch, protections
```

ALTERNATIVELY (and this is the cleaner approach): the form is fully dynamic. The `CreateChallenge.jsx` page fetches the category model, reads formFields, and renders inputs automatically based on the field type (text, select, number, textarea). No per-category React components needed. The model.js IS the form definition.

### Update sidebar navigation
```
Sidebar:
  Dashboard       (/)
  Create          (/create)         ← NEW
  Queue           (/queue)          ← renamed from Jobs
  Packages        (/packages)
```

### Update the flow
Current: Dashboard has a submit form embedded at the top.
New: Dashboard shows stats and queue only. The "Create a Challenge" action is its own page accessible from the sidebar, with the category dropdown and dynamic form.

## WHAT NOT TO CHANGE
- The API routes for implement, jobs, specs, challenges, reviews stay the same
- The database schema stays the same  
- The researcher module stays the same
- The queue infrastructure stays the same
- The Phase 2 researcher agent files stay the same

## EXECUTION ORDER
1. Create `backend/categories/` folder structure with all 6 category folders
2. Write model.js for each category (web first, then copy pattern for others)
3. Write mock builder.js for each category
4. Write placeholder prompt.md and schema.js for each
5. Create `backend/categories/index.js` registry
6. Add `GET /api/categories` endpoint
7. Update builder worker to use category registry
8. Create `frontend/src/pages/CreateChallenge.jsx` with category dropdown
9. Create dynamic form renderer that reads formFields from category model
10. Update sidebar navigation
11. Move submit form out of Dashboard into the Create page
12. Test: select "Web" category, fill form, submit, verify job appears in queue with correct category

## WHAT SUCCESS LOOKS LIKE
1. `GET /api/categories` returns all 6 categories with name, description, color, icon, and formFields
2. Frontend sidebar has Dashboard, Create, Queue, Packages
3. Clicking "Create" shows a page with a category dropdown
4. Selecting "Web" shows: CVE ID field, tech stack picker, vuln type dropdown, plus the common description and difficulty fields
5. Selecting "Forensics" shows: artifact type picker, evidence description, plus common fields
6. Submitting a web challenge creates a job with category "web" and the extra fields stored
7. Adding a 7th category means: create one folder with 5 files in backend/categories/, register in index.js, and the frontend auto-discovers it via the API. Zero frontend code changes.
