# Ali's Feedback: Duplicate Checker + Rejection Rework Cycle

## CONTEXT
Ali asked two questions:
1. "How does the system prevent duplicate challenges?" — It doesn't yet. We need a checker.
2. "What happens after a challenge is rejected?" — Currently it's dead. We need a rework cycle.

These are quality control features that go into the existing pipeline BEFORE we add more categories.

## FEATURE 1: REJECTION REWORK CYCLE

### The Problem
Right now, when a reviewer rejects a spec or build, the job status becomes "rejected" and it's dead. The reviewer's feedback is saved but never used. If the spec was 90% good but the difficulty was wrong, the entire research is wasted.

### The Solution
When a reviewer rejects with feedback, the system should automatically rework the output using AI, incorporating the feedback, and resubmit for review. This creates an iteration loop:

```
AI generates → Human reviews → Rejects with feedback → AI reworks using feedback → Human reviews again → ...
```

### How It Works

#### Spec Rejection Rework
1. Reviewer clicks "Reject" and writes feedback (e.g., "Difficulty should be hard not medium, the exploit path needs a WAF bypass step")
2. Instead of status becoming "rejected", status becomes "reworking_spec"
3. The system sends the ORIGINAL spec + the rejection feedback to Claude with a rework prompt
4. Claude generates a REVISED spec that addresses the feedback
5. The revised spec replaces the old one in the database
6. Status goes back to "pending_spec_review"
7. The reviewer sees the revised spec with a banner: "Revision 2 — reworked based on your feedback"
8. If approved, proceed to builder. If rejected again with new feedback, repeat the cycle.
9. MAX 3 AI REWORK ITERATIONS. After 3 rejections, status becomes "rejected_final" and the reviewer must either manually edit and approve, or abandon it.

#### Build Rejection Rework
Same pattern but for the builder output:
1. Reviewer rejects built challenge with feedback (e.g., "The Dockerfile doesn't expose the right port, the exploit script has a bug")
2. Status becomes "reworking_build"
3. System sends the ORIGINAL spec + GENERATED FILES + rejection feedback to Claude
4. Claude generates revised files
5. Status goes back to "pending_build_review"
6. Max 3 iterations, same as spec.

### New Job States
Add these to the state machine:
- `reworking_spec` — AI is revising the spec based on feedback
- `reworking_build` — AI is revising the build based on feedback

### Database Changes
Add to the `jobs` table:
- `spec_revision` INTEGER DEFAULT 1 — tracks which revision of the spec we're on
- `build_revision` INTEGER DEFAULT 1 — tracks which revision of the build we're on

The `reviews` table already stores the feedback in the `notes` field. No changes needed there.

### New Prompt Templates Needed

#### agents/prompts/rework-spec.md
```
You are revising a CTF challenge specification based on reviewer feedback.

Here is the ORIGINAL spec that was rejected:
{ORIGINAL_SPEC}

Here is the reviewer's feedback explaining what needs to change:
{FEEDBACK}

Generate a REVISED spec that addresses ALL of the reviewer's feedback while keeping everything else from the original spec that was not mentioned in the feedback.

Output format: same JSON schema as the original spec. ONLY output valid JSON.
```

#### agents/prompts/rework-build.md
```
You are revising CTF challenge files based on reviewer feedback.

Here is the approved challenge spec:
{SPEC}

Here are the ORIGINAL generated files that were rejected:
{ORIGINAL_FILES}

Here is the reviewer's feedback explaining what needs to change:
{FEEDBACK}

Generate REVISED files that address ALL of the reviewer's feedback. Keep files that were not mentioned in the feedback unchanged.

Output format: same JSON schema with "files" object. ONLY output valid JSON.
```

### Backend Changes

#### Update POST /api/specs/:jobId/review
When action is "reject" and notes are provided:
1. Check spec_revision count. If < 3, set status to "reworking_spec" and push a rework job to the researcher queue.
2. If >= 3, set status to "rejected_final".
3. Return the new status in the response so the frontend knows what happened.

NEW: Also add action "reject_final" for when the reviewer wants to kill it immediately without rework (e.g., the CVE is not suitable for a challenge at all).

```javascript
// Updated review logic
if (action === "reject") {
  const job = getJob(jobId);
  if (notes && notes.trim() && job.spec_revision < 3) {
    // Auto-rework: send to AI for revision
    updateJob(jobId, { status: "reworking_spec", spec_revision: job.spec_revision + 1 });
    researcherQueue.add("rework-spec", { jobId, feedback: notes, revision: job.spec_revision + 1 });
    return res.json({ status: "reworking_spec", message: "AI is reworking the spec based on your feedback", revision: job.spec_revision + 1 });
  } else {
    // No feedback or max revisions reached
    updateJob(jobId, { status: "rejected_final" });
    return res.json({ status: "rejected_final" });
  }
}
```

Same pattern for POST /api/challenges/:jobId/review.

#### Update the researcher worker
Add a handler for "rework-spec" jobs:
1. Load the current spec from the database
2. Load the rejection feedback from the latest review
3. Send both to Claude with the rework-spec.md prompt
4. Validate the revised spec with Zod
5. Update the spec in the database (overwrite spec_json)
6. Set status back to "pending_spec_review"

#### Update the builder worker
Add a handler for "rework-build" jobs:
1. Load the current spec AND the current generated files
2. Load the rejection feedback
3. Send everything to Claude with the rework-build.md prompt
4. Save revised files to storage (overwrite)
5. Set status back to "pending_build_review"

### Frontend Changes

#### Spec Review page
- Show a revision badge: "Revision 1 of 3" or "Revision 2 of 3 — reworked from feedback"
- When rejecting, the notes field should be labeled "Feedback for AI rework (required)" and be mandatory
- Add a separate "Reject permanently" button that kills it without rework
- After rejection, show a loading state: "AI is reworking based on your feedback..." then auto-refresh when the new spec is ready
- Show the previous rejection feedback above the spec so the reviewer can verify the AI addressed it

#### Build Review page
- Same revision badge and feedback flow as spec review
- Show diff between original and revised files if possible (nice to have, not required for MVP)

#### Dashboard / Queue
- New status badges: "reworking_spec" (purple pulse), "reworking_build" (purple pulse), "rejected_final" (red, no rework)
- Jobs in rework should show "Revising..." with the revision count

---

## FEATURE 2: DUPLICATE CHALLENGE CHECKER

### The Problem
Nothing stops someone from submitting CVE-2023-22527 twice, or submitting two different ideas that would result in nearly identical challenges (e.g., "SQL injection in a Flask app" and "SQLi in a Python web app").

### The Solution
A duplicate checker that runs at two points:
1. **At submission time** (POST /api/implement): check if the CVE ID already exists
2. **After research** (before moving to pending_spec_review): check if the generated spec is too similar to an existing spec

### Level 1: Exact CVE Duplicate Check (already partially exists)
The implement route already checks for existing CVE IDs. But it needs improvement:
- Currently only checks non-rejected/non-failed jobs. Should ALSO check "ready" (completed) challenges.
- Should return the existing challenge details so the user can decide.

Update the dedup check in `POST /api/implement`:
```javascript
// Check ALL jobs with this CVE, including completed ones
const existing = findJobByCveId(cveId); // searches all statuses
if (existing) {
  return {
    duplicate: true,
    existingJob: {
      id: existing.id,
      status: existing.status,
      challengeName: getSpecForJob(existing.id)?.challengeName || "Unknown",
      createdAt: existing.created_at,
    },
    message: `CVE ${cveId} already has a challenge: "${existing.challengeName}" (${existing.status})`,
  };
}
```

The frontend should show a warning modal: "This CVE already has a challenge. Do you want to create another one anyway?" with Force and Cancel buttons.

### Level 2: Similarity Check on Spec Content
After the researcher generates a spec, before it moves to pending_spec_review, run a similarity check against all existing specs in the database.

Create `backend/researcher/duplicateChecker.js`:

```javascript
/**
 * Check if a new spec is too similar to existing specs.
 * Compares: CVE ID (exact), challenge name (fuzzy), tech stack (overlap), 
 * vulnerability type (exact), category + difficulty combo.
 * Returns: { isDuplicate: boolean, similarChallenges: [...], score: 0-100 }
 */
function checkDuplicate(newSpec) {
  const allSpecs = getAllExistingSpecs(); // from database
  const results = [];
  
  for (const existing of allSpecs) {
    let score = 0;
    
    // Same CVE = very high similarity
    if (newSpec.cveId && existing.cveId && newSpec.cveId === existing.cveId) score += 50;
    
    // Same CWE = moderate similarity
    if (newSpec.cwe?.id && existing.cwe?.id && newSpec.cwe.id === existing.cwe.id) score += 20;
    
    // Tech stack overlap
    const stackOverlap = intersect(newSpec.techStack, existing.techStack);
    if (stackOverlap.length >= 2) score += 15;
    
    // Same category + difficulty
    if (newSpec.category === existing.category && newSpec.difficulty === existing.difficulty) score += 10;
    
    // Challenge name similarity (Levenshtein or simple word overlap)
    const nameScore = wordOverlapScore(newSpec.challengeName, existing.challengeName);
    if (nameScore > 0.6) score += 15;
    
    if (score >= 40) {
      results.push({ existingSpec: existing, similarityScore: score });
    }
  }
  
  results.sort((a, b) => b.similarityScore - a.similarityScore);
  
  return {
    isDuplicate: results.length > 0 && results[0].similarityScore >= 60,
    isWarning: results.length > 0 && results[0].similarityScore >= 40,
    similarChallenges: results.slice(0, 3), // top 3 similar
    highestScore: results[0]?.similarityScore || 0,
  };
}
```

### Where the Check Runs
In the researcher worker, AFTER generating the spec and BEFORE saving to database:

```javascript
// After spec generation, before saving
const dupCheck = checkDuplicate(spec);

if (dupCheck.isDuplicate) {
  // Score >= 60: flag it but still save. Add a warning to the spec.
  spec.duplicateWarning = {
    message: "This challenge is very similar to an existing one",
    similarTo: dupCheck.similarChallenges[0].existingSpec.challengeName,
    score: dupCheck.highestScore,
  };
}

// Save spec (always save, but with the warning attached)
createSpec({ jobId, specJson: spec, ... });
updateJobStatus(jobId, "pending_spec_review");
```

The reviewer sees the warning on the Spec Review page and decides whether to proceed or reject.

### Frontend Changes for Duplicate Checker

#### Submit form (Create Challenge page)
- After submitting CVE IDs, if any return as duplicates, show a warning card:
  "CVE-2023-22527 already has a challenge: 'Shadow Confluence' (ready). Create another?"
  [Force Create] [Skip This CVE]

#### Spec Review page
- If the spec has a `duplicateWarning` field, show a yellow banner at the top:
  "Similar challenge detected: 'Shadow Confluence' (82% match). Review carefully before approving."
- Link to the existing similar challenge so the reviewer can compare.

### Database Changes for Duplicate Checker
No schema changes needed. The duplicate check reads existing specs from the specs table. The warning is stored inside the spec_json field.

---

## EXECUTION ORDER

1. Add `spec_revision` and `build_revision` columns to jobs table
2. Add new states to the state machine: `reworking_spec`, `reworking_build`, `rejected_final`
3. Create `agents/prompts/rework-spec.md` and `agents/prompts/rework-build.md`
4. Update `POST /api/specs/:jobId/review` to handle rejection rework flow
5. Update `POST /api/challenges/:jobId/review` to handle build rejection rework flow
6. Add rework handler to researcher worker
7. Add rework handler to builder worker
8. Create `backend/researcher/duplicateChecker.js`
9. Update researcher worker to run duplicate check after spec generation
10. Update `POST /api/implement` to check completed challenges too
11. Update frontend Spec Review page: revision badge, mandatory feedback, rework loading state
12. Update frontend Build Review page: same revision flow
13. Update frontend Create page: duplicate warning on submission
14. Update StatusBadge component with new states
15. Test: submit CVE, reject spec with feedback, verify AI reworks it, approve revised spec
16. Test: submit same CVE again, verify duplicate warning appears
17. Test: reject spec 3 times, verify it becomes rejected_final on the 4th rejection

## WHAT SUCCESS LOOKS LIKE

### Rework cycle test:
1. Submit CVE-2023-22527
2. Spec arrives at pending_spec_review with "Revision 1"
3. Reject with feedback: "Change difficulty to hard and add a WAF bypass step to the exploit path"
4. Status briefly shows "reworking_spec"
5. Within 30 seconds, spec is back at pending_spec_review with "Revision 2"
6. The revised spec has difficulty "hard" and the exploit path includes a WAF bypass step
7. Approve, builder runs, reject build with feedback: "The Dockerfile should use python:3.12-slim not 3.11"
8. Build reworks, comes back with the correct base image
9. Approve, job reaches "ready"

### Duplicate checker test:
1. Submit CVE-2023-22527, let it go all the way to "ready"
2. Submit CVE-2023-22527 again
3. Frontend shows warning: "This CVE already has a challenge"
4. Click "Force Create" to proceed anyway
5. Researcher generates spec, duplicate checker flags it: "82% similar to Shadow Confluence"
6. Reviewer sees the warning banner on Spec Review page
7. Submit a custom idea: "OGNL injection in Confluence" (no CVE ID)
8. Duplicate checker still catches it because same CWE + same tech stack + similar name

### Edge case test:
1. Submit a CVE, reject spec 3 times with different feedback each time
2. On the 3rd rejection, verify spec was reworked each time (revisions 1, 2, 3)
3. On the 4th review, if rejected, status becomes "rejected_final" (no more AI rework)
4. Verify the reviewer can still manually edit and approve a rejected_final spec if they choose
