# CTF Challenge Orchestrator — Claude Code Prompt

## WHO YOU ARE BUILDING THIS FOR
Bhargav Raj Dutta, Offensive Lab Engineer and CTF Specialist at Exploit3rs Cyber Security Academy (Dubai, UAE). CTO is Ali Omar, CEO is Juma Alshamshi. This is an internal Exploit3rs platform (not a personal project).

## WHAT THIS IS
An AI-powered full-stack platform that automates CTF challenge lab creation. It uses AI agents (Claude API) to research vulnerabilities and build challenge labs, with a human approval dashboard in between. Target: 10 challenge labs per day across 6 categories.

## THE PIPELINE (how it works end to end)
```
User submits CVE IDs or custom ideas
  → Researcher Agent (Claude API) generates a challenge spec document
    → Human reviews spec on dashboard (approve / reject / edit)
      → Builder Agent (Claude API) generates all challenge code and artifacts
        → Human reviews built challenge on dashboard (approve / reject)
          → ZIP packager creates downloadable challenge package
```

Two input modes:
1. **CVE mode**: paste CVE IDs like "CVE-2023-22527", system fetches NVD data automatically
2. **Idea mode**: write a description like "PCAP with DNS tunneling exfiltration", pick category and difficulty

Six challenge categories (web is Phase 1 priority, others Phase 4):
- Web Exploitation → Dockerfile + Flask/Express app + exploit script + writeup
- Forensics → PCAP generation scripts, log files, disk image specs + writeup
- Cryptography → Encryption script + ciphertext + solver script + writeup
- OSINT → Fake profiles, EXIF metadata, breadcrumb trails + writeup
- Network → PCAP captures, router configs, topology + writeup
- Pwn → C source, Makefile, exploit script + writeup

## JOB STATE MACHINE
Every CVE/idea transitions through these states:
```
queued → researching → pending_spec_review → spec_approved → building → pending_build_review → ready
                ↓                 ↓                                ↓                  ↓
              failed           rejected                      build_failed          rejected
```

## TECH STACK (locked in)
- **Backend**: Express.js, Node 20
- **Frontend**: React 18 + Vite
- **Database**: SQLite via sql.js (pure WASM, no native deps). NOT Prisma (engine download fails in restricted environments)
- **Job Queue**: BullMQ + Redis
- **AI**: Claude API (Sonnet) via @anthropic-ai/sdk
- **Validation**: Zod for all input validation and AI output validation
- **Storage**: Local filesystem for MVP (mirrors S3 key patterns for future swap)

## FOLDER STRUCTURE
```
ctf-orchestrator/
├── package.json              # Monorepo: "npm run dev" starts backend + frontend
├── .env                      # All config vars
├── .gitignore
├── backend/
│   ├── package.json
│   ├── server.js             # Express app entry point
│   ├── config.js             # Env var loader
│   ├── db/
│   │   ├── client.js         # sql.js database layer with CRUD for all tables
│   │   └── seed.js           # Test data seeder
│   ├── api/
│   │   ├── routes/
│   │   │   ├── implement.js  # POST /api/implement (submit CVEs or ideas)
│   │   │   ├── jobs.js       # GET /api/jobs, GET /api/jobs/:id
│   │   │   ├── specs.js      # GET /api/specs/:jobId, POST /api/specs/:jobId/review
│   │   │   ├── challenges.js # GET /api/challenges/:jobId, POST /api/challenges/:jobId/review
│   │   │   └── stats.js      # GET /api/stats
│   │   └── middleware/
│   │       └── auth.js       # Bearer token auth (skipped in dev)
│   ├── queue/
│   │   ├── index.js          # Redis connection + BullMQ queue definitions
│   │   └── workers/
│   │       ├── researcherWorker.js  # Phase 1: mock (3s delay). Phase 2: real Claude calls
│   │       └── builderWorker.js     # Phase 1: mock (5s delay). Phase 3: real code gen
│   ├── researcher/           # (Phase 2) NVD client, ref collector, enricher, spec generator
│   ├── builder/              # (Phase 3) Category router + specialists
│   │   └── specialists/      # webBuilder.js, forensicsBuilder.js, etc.
│   ├── agents/               # (Phase 2) Base agent class, Claude SDK wrapper
│   │   └── prompts/          # .md prompt templates per agent
│   └── storage/
│       ├── specs/            # Saved spec JSON files
│       ├── challenges/       # Built challenge files
│       └── packages/         # Final ZIP packages
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── App.jsx
│       ├── main.jsx
│       ├── index.css
│       ├── api/
│       │   └── client.js     # Fetch wrapper for all backend endpoints
│       ├── pages/
│       │   ├── Dashboard.jsx       # Main view: stats + job queue + submit form
│       │   ├── SpecReview.jsx      # Review AI-generated spec: approve/reject/edit
│       │   ├── BuildReview.jsx     # Review built challenge: code viewer + approve/reject
│       │   └── JobDetail.jsx       # Full job history and status
│       └── components/
│           ├── Layout.jsx          # Sidebar nav + header
│           ├── JobTable.jsx        # Job list with status badges
│           ├── SubmitForm.jsx      # Dual-mode: CVE IDs or custom idea
│           ├── StatsCards.jsx      # Pipeline stats overview
│           ├── SpecViewer.jsx      # Renders spec JSON as readable card
│           └── StatusBadge.jsx     # Color-coded status pill
```

## DATABASE SCHEMA (sql.js — already implemented in db/client.js)
5 tables: batches, jobs, specs, challenges, reviews
- **batches**: id, mode (cve|idea), total_jobs, created_at
- **jobs**: id, batch_id, cve_id, idea_text, category, difficulty, status, error_message, retry_count, timestamps
- **specs**: id, job_id (unique), spec_json, token_usage, generation_time_ms
- **challenges**: id, job_id (unique), file_manifest (JSON array), token_usage, generation_time_ms
- **reviews**: id, job_id, stage (spec|build), action (approve|reject|edit_approve), notes, edited_data

## API ENDPOINTS
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/health | Health check |
| POST | /api/implement | Submit CVE batch or idea batch |
| GET | /api/jobs | List jobs (filterable: status, category, batchId) |
| GET | /api/jobs/:id | Single job with all relations |
| GET | /api/specs/:jobId | Get spec for review |
| POST | /api/specs/:jobId/review | Submit spec review (approve/reject/edit_approve) |
| GET | /api/challenges/:jobId | Get built challenge for review |
| POST | /api/challenges/:jobId/review | Submit build review (approve/reject) |
| GET | /api/stats | Dashboard stats: pipeline counts, tokens, cost, approval rate |

## IMPLEMENT REQUEST FORMATS
```json
// CVE mode
{ "mode": "cve", "items": ["CVE-2023-22527", "CVE-2024-50379"] }

// Idea mode
{ "mode": "idea", "items": [
  { "description": "PCAP with DNS tunneling exfil", "category": "forensics", "difficulty": "medium" }
]}
```

## EXISTING CODE
The backend code is already written and located in the project. All the files listed in the folder structure above exist. The db/client.js uses sql.js (WASM SQLite) with full CRUD methods for all 5 tables. The queue workers are currently mock implementations that simulate 3-5 second delays and produce fake spec/challenge data.

## PHASE 1 TASKS (what to do NOW)

### Priority 1: Get the backend running and all endpoints testable
1. Make sure `npm run dev` in the root starts the backend (and frontend when ready)
2. Verify Redis connection works (BullMQ requires Redis running on localhost:6379)
3. Test every API endpoint with curl or a test script:
   - POST /api/implement with CVE mode (batch of 3 CVEs)
   - Watch jobs transition: queued → researching → pending_spec_review (3 second mock delay)
   - GET /api/jobs to see the queue
   - GET /api/specs/:jobId to see the mock spec
   - POST /api/specs/:jobId/review with {"action":"approve"} 
   - Watch job transition: spec_approved → building → pending_build_review (5 second mock delay)
   - POST /api/challenges/:jobId/review with {"action":"approve"}
   - Verify job reaches "ready" status
   - GET /api/stats to see pipeline stats
4. Write a test script (backend/test.sh) that runs through the full pipeline automatically

### Priority 2: Build the frontend dashboard
Build a React dashboard with these pages:

**Dashboard page (/):**
- Stats cards at top: total jobs, jobs today, tokens used, estimated cost, approval rate
- Pipeline overview: visual count of jobs in each state
- Submit form with two tabs: "CVE Batch" (textarea for CVE IDs, one per line) and "Custom Idea" (description input, category dropdown, difficulty dropdown)
- Job queue table below: columns for ID, CVE/Idea, Category, Status (color badge), Created, Actions

**Spec Review page (/review/spec/:jobId):**
- Left panel: spec data rendered as a readable card (challenge name, narrative, difficulty, points, tech stack, exploit path, flags, anti-AI measures, reviewer note)
- Right panel: action buttons (Approve, Reject with reason input, Edit fields inline then approve)

**Build Review page (/review/build/:jobId):**  
- Code viewer with the file manifest listed
- Spec summary at top for reference
- Action buttons (Approve, Reject with feedback)

**Job Detail page (/jobs/:id):**
- Full job timeline: every status transition with timestamps
- Spec data (if exists), challenge data (if exists), all reviews

**Design direction for the dashboard:**
- Dark theme (this is a hacker/security tool)
- Color scheme: deep navy (#0a192f) background, light text (#ccd6f6), teal accent (#64ffda) for success/approve, coral (#ff6b6b) for reject/error, amber (#ffd93d) for pending/warning
- Monospace font for code and IDs (JetBrains Mono or Fira Code from Google Fonts)
- Sans-serif for UI text (Inter)
- Status badges: queued (gray), researching (blue pulse), pending_review (amber), approved (teal), building (purple pulse), ready (green), failed/rejected (red)
- Clean, minimal layout. No clutter. Think terminal meets modern dashboard.
- Sidebar navigation: Dashboard, Queue, Packages
- No emojis anywhere in the UI

### Priority 3: Verify full pipeline works end to end
Submit 3 CVEs via the dashboard, watch them process through mock workers, review specs, approve them, watch builder run, review builds, approve them, see them reach "ready" status.

## IMPORTANT NOTES
- Do NOT use Prisma. The db/client.js already implements sql.js (WASM SQLite). Use the existing db layer.
- Redis must be running locally for BullMQ. If Redis is not available, gracefully handle the error and suggest the user start Redis.
- The workers are intentionally mock for Phase 1. Do not implement real Claude API calls yet. That is Phase 2.
- Keep all AI prompt templates as separate .md files in agents/prompts/ even though they are not used yet. Create placeholder files.
- Use Zod for ALL input validation on API routes. This is already done in the existing code.
- The frontend should poll GET /api/jobs every 3 seconds to show real-time status updates (upgrade to SSE/WebSocket later).
- This is for Exploit3rs Cyber Security Academy. The branding should reference Exploit3rs in the header.
- Flag format is always Exploit3rs{...}
- Anti-AI countermeasures are a core feature, not an afterthought. The spec document must always include anti-AI fields.

## WHAT SUCCESS LOOKS LIKE
When done, I should be able to:
1. Run `npm run dev` and see both backend (port 3001) and frontend (port 5173) start
2. Open the dashboard, paste 3 CVE IDs, click Submit
3. Watch the job table update in real time as the mock workers process
4. Click a job in "pending_spec_review" to see the spec
5. Click Approve, watch it transition to building
6. Click the job in "pending_build_review" to see the challenge files
7. Click Approve, see status change to "ready"
8. See accurate stats on the dashboard
