const express = require("express");
const cors = require("cors");
const config = require("./config");
const { initDb } = require("./db/client");

const app = express();
app.use(cors({ origin: "http://localhost:5173", credentials: true }));
app.use(express.json());

// Request logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on("finish", () => {
    if (req.path !== "/api/health") console.log(`${req.method} ${req.path} ${res.statusCode} ${Date.now() - start}ms`);
  });
  next();
});

// Health
app.get("/api/health", (req, res) => res.json({ status: "ok", version: "1.0.0" }));

// Routes
app.use("/api/implement", require("./api/routes/implement"));
app.use("/api/jobs", require("./api/routes/jobs"));
app.use("/api/specs", require("./api/routes/specs"));
app.use("/api/challenges", require("./api/routes/challenges"));
app.use("/api/stats", require("./api/routes/stats"));

// 404
app.use((req, res) => res.status(404).json({ error: `Not found: ${req.method} ${req.path}` }));

// Error handler
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: "Internal server error" }); });

async function start() {
  try {
    await initDb();

    // Start workers (mock for Phase 1)
    const { startResearcherWorker } = require("./queue/workers/researcherWorker");
    const { startBuilderWorker } = require("./queue/workers/builderWorker");
    startResearcherWorker();
    startBuilderWorker();

    app.listen(config.port, () => {
      console.log(`\n${"=".repeat(50)}`);
      console.log("  CTF Challenge Orchestrator");
      console.log("  Exploit3rs Cyber Security Academy");
      console.log(`${"=".repeat(50)}`);
      console.log(`  Backend:    http://localhost:${config.port}`);
      console.log(`  Dashboard:  http://localhost:5173`);
      console.log(`${"=".repeat(50)}\n`);
    });
  } catch (err) {
    console.error("[Startup] Failed:", err);
    process.exit(1);
  }
}

start();
