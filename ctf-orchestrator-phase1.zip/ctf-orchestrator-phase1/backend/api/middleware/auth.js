const config = require("../../config");

function authMiddleware(req, res, next) {
  // Skip auth in development if no token is set
  if (config.nodeEnv === "development" && config.auth.apiToken === "dev-token-change-in-production") {
    return next();
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization header" });
  }

  const token = authHeader.split(" ")[1];
  if (token !== config.auth.apiToken) {
    return res.status(403).json({ error: "Invalid API token" });
  }

  next();
}

module.exports = { authMiddleware };
