const { Router } = require("express");
const { z } = require("zod");
const db = require("../../db/client");
const { builderQueue } = require("../../queue");
const router = Router();

router.get("/:jobId", (req, res) => {
  try {
    const spec = db.specs.findByJobId(req.params.jobId);
    if (!spec) return res.status(404).json({ error: "Spec not found" });
    const job = db.jobs.findById(req.params.jobId);
    res.json({ ...spec, job, specData: JSON.parse(spec.spec_json) });
  } catch (err) {
    console.error("[Specs] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

const reviewSchema = z.object({
  action: z.enum(["approve", "reject", "edit_approve"]),
  notes: z.string().optional(),
  editedData: z.record(z.any()).optional(),
});

router.post("/:jobId/review", async (req, res) => {
  try {
    const parsed = reviewSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Validation failed", details: parsed.error.issues });

    const { action, notes, editedData } = parsed.data;
    const { jobId } = req.params;
    const job = db.jobs.findById(jobId);
    if (!job) return res.status(404).json({ error: "Job not found" });
    if (job.status !== "pending_spec_review") return res.status(400).json({ error: `Job is ${job.status}, expected pending_spec_review` });

    db.reviews.create({ jobId, stage: "spec", action, notes, editedData: editedData ? JSON.stringify(editedData) : null });

    if (action === "reject") {
      db.jobs.update(jobId, { status: "rejected" });
      return res.json({ jobId, status: "rejected" });
    }

    if (action === "edit_approve" && editedData) {
      const spec = db.specs.findByJobId(jobId);
      if (spec) {
        const updated = { ...JSON.parse(spec.spec_json), ...editedData };
        db.specs.updateByJobId(jobId, { spec_json: JSON.stringify(updated, null, 2) });
      }
    }

    db.jobs.update(jobId, { status: "spec_approved" });
    await builderQueue.add(`build-${jobId}`, { jobId }, { attempts: 2, backoff: { type: "exponential", delay: 30000 } });
    res.json({ jobId, status: "spec_approved", message: "Queued for building" });
  } catch (err) {
    console.error("[Specs] Review error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
