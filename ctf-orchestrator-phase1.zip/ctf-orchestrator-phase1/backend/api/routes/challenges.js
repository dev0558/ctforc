const { Router } = require("express");
const { z } = require("zod");
const db = require("../../db/client");
const router = Router();

router.get("/:jobId", (req, res) => {
  try {
    const challenge = db.challenges.findByJobId(req.params.jobId);
    if (!challenge) return res.status(404).json({ error: "Challenge not found" });
    const job = db.jobs.findById(req.params.jobId);
    const spec = db.specs.findByJobId(req.params.jobId);
    res.json({ ...challenge, files: JSON.parse(challenge.file_manifest), job, spec: spec ? { specData: JSON.parse(spec.spec_json) } : null });
  } catch (err) {
    console.error("[Challenges] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/:jobId/review", async (req, res) => {
  try {
    const parsed = z.object({ action: z.enum(["approve", "reject"]), notes: z.string().optional() }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Validation failed" });

    const { action, notes } = parsed.data;
    const { jobId } = req.params;
    const job = db.jobs.findById(jobId);
    if (!job) return res.status(404).json({ error: "Job not found" });
    if (job.status !== "pending_build_review") return res.status(400).json({ error: `Job is ${job.status}, expected pending_build_review` });

    db.reviews.create({ jobId, stage: "build", action, notes });

    if (action === "reject") {
      db.jobs.update(jobId, { status: "rejected" });
      return res.json({ jobId, status: "rejected" });
    }

    db.jobs.update(jobId, { status: "ready", completed_at: new Date().toISOString() });
    res.json({ jobId, status: "ready", message: "Challenge approved and ready" });
  } catch (err) {
    console.error("[Challenges] Review error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
