const { Router } = require("express");
const { z } = require("zod");
const db = require("../../db/client");
const { researcherQueue } = require("../../queue");

const router = Router();

const CVE_REGEX = /^CVE-\d{4}-\d{4,7}$/;
const CATEGORIES = ["web", "forensics", "crypto", "osint", "network", "pwn"];
const DIFFICULTIES = ["easy", "medium", "hard"];

const implementSchema = z.union([
  z.object({
    mode: z.literal("cve"),
    items: z.array(z.string().regex(CVE_REGEX, "Invalid CVE format")).min(1).max(10),
    force: z.boolean().optional(),
  }),
  z.object({
    mode: z.literal("idea"),
    items: z.array(z.object({
      description: z.string().min(10).max(500),
      category: z.enum(CATEGORIES),
      difficulty: z.enum(DIFFICULTIES),
    })).min(1).max(10),
  }),
]);

router.post("/", async (req, res) => {
  try {
    const parsed = implementSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Validation failed", details: parsed.error.issues });
    }

    const { mode, items } = parsed.data;
    const force = parsed.data.force || false;
    const skipped = [];
    const toProcess = [];

    if (mode === "cve") {
      for (const cveId of items) {
        const existing = db.jobs.findExisting(cveId);
        if (existing && !force) {
          skipped.push({ cveId, reason: `Already exists: ${existing.status}`, jobId: existing.id });
        } else {
          toProcess.push({ cveId });
        }
      }
    } else {
      items.forEach((item) => toProcess.push(item));
    }

    if (toProcess.length === 0) {
      return res.json({ batchId: null, message: "All items skipped (duplicates)", skipped, jobs: [] });
    }

    const batch = db.batches.create({ mode, totalJobs: toProcess.length });
    const jobResults = [];

    for (const item of toProcess) {
      const job = db.jobs.create({
        batchId: batch.id,
        category: mode === "cve" ? "web" : item.category,
        cveId: mode === "cve" ? item.cveId : undefined,
        ideaText: mode === "idea" ? item.description : undefined,
        difficulty: mode === "idea" ? item.difficulty : undefined,
      });

      await researcherQueue.add(`research-${job.id}`, {
        jobId: job.id, cveId: job.cveId, ideaText: job.ideaText, mode,
      }, { attempts: 3, backoff: { type: "exponential", delay: 30000 } });

      jobResults.push({ id: job.id, cveId: job.cveId || null, ideaText: job.ideaText || null, category: job.category, status: "queued" });
    }

    res.status(201).json({ batchId: batch.id, mode, totalQueued: jobResults.length, totalSkipped: skipped.length, jobs: jobResults, skipped });
  } catch (err) {
    console.error("[Implement] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
