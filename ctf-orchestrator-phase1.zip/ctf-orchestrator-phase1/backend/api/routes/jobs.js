const { Router } = require("express");
const db = require("../../db/client");
const router = Router();

router.get("/", (req, res) => {
  try {
    const { status, category, batchId, limit = "50", offset = "0" } = req.query;
    const jobs = db.jobs.findMany({ status, category, batchId, limit: parseInt(limit), offset: parseInt(offset) });
    const total = db.jobs.count({ status });
    res.json({ jobs, total, limit: parseInt(limit), offset: parseInt(offset) });
  } catch (err) {
    console.error("[Jobs] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id", (req, res) => {
  try {
    const job = db.jobs.findByIdFull(req.params.id);
    if (!job) return res.status(404).json({ error: "Job not found" });
    if (job.spec) job.spec.specData = JSON.parse(job.spec.spec_json);
    if (job.challenge) job.challenge.files = JSON.parse(job.challenge.file_manifest);
    res.json(job);
  } catch (err) {
    console.error("[Jobs] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
