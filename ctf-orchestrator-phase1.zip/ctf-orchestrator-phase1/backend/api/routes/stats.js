const { Router } = require("express");
const db = require("../../db/client");
const router = Router();

router.get("/", (req, res) => {
  try {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const statusCounts = db.jobs.groupByStatus();
    const categoryCounts = db.jobs.groupByCategory();
    const actionCounts = db.reviews.groupByAction();

    const approved = (actionCounts.find((a) => a.action === "approve")?.count || 0) +
                     (actionCounts.find((a) => a.action === "edit_approve")?.count || 0);
    const rejected = actionCounts.find((a) => a.action === "reject")?.count || 0;
    const totalReviews = approved + rejected;

    const totalTokens = db.specs.sumTokens() + db.challenges.sumTokens();
    const sc = Object.fromEntries(statusCounts.map((s) => [s.status, s.count]));

    res.json({
      totalJobs: db.jobs.count(),
      jobsToday: db.jobs.count({ createdAfter: today.toISOString() }),
      statusBreakdown: sc,
      categoryBreakdown: Object.fromEntries(categoryCounts.map((c) => [c.category, c.count])),
      totalSpecs: db.specs.count(),
      totalChallenges: db.challenges.count(),
      totalTokens,
      estimatedCostUsd: Math.round((totalTokens / 1000000) * 9 * 100) / 100,
      approvalRate: totalReviews > 0 ? Math.round((approved / totalReviews) * 100) : 0,
      pipeline: {
        queued: sc.queued || 0, researching: sc.researching || 0,
        pendingSpecReview: sc.pending_spec_review || 0, building: sc.building || 0,
        pendingBuildReview: sc.pending_build_review || 0, ready: sc.ready || 0,
        failed: sc.failed || 0, rejected: sc.rejected || 0,
      },
    });
  } catch (err) {
    console.error("[Stats] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
