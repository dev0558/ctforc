const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../.env") });

module.exports = {
  port: parseInt(process.env.PORT || "3001"),
  nodeEnv: process.env.NODE_ENV || "development",
  database: {
    url: process.env.DATABASE_URL || "file:./dev.db",
  },
  redis: {
    host: process.env.REDIS_HOST || "127.0.0.1",
    port: parseInt(process.env.REDIS_PORT || "6379"),
  },
  claude: {
    apiKey: process.env.ANTHROPIC_API_KEY || "",
    model: process.env.CLAUDE_MODEL || "claude-sonnet-4-20250514",
  },
  auth: {
    apiToken: process.env.API_TOKEN || "dev-token-change-in-production",
  },
  storage: {
    basePath: path.resolve(__dirname, process.env.STORAGE_PATH || "./storage"),
  },
  queue: {
    researcherConcurrency: parseInt(process.env.RESEARCHER_CONCURRENCY || "2"),
    builderConcurrency: parseInt(process.env.BUILDER_CONCURRENCY || "1"),
    researcherMaxRetries: parseInt(process.env.RESEARCHER_MAX_RETRIES || "3"),
    builderMaxRetries: parseInt(process.env.BUILDER_MAX_RETRIES || "2"),
  },
};
