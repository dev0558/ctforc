const { Worker } = require("bullmq");
const { connection } = require("../index");
const db = require("../../db/client");
const config = require("../../config");

function startBuilderWorker() {
  const worker = new Worker("builder", async (job) => {
    const { jobId } = job.data;
    console.log(`[Builder] Processing ${jobId}`);

    db.jobs.update(jobId, { status: "building" });
    await new Promise((r) => setTimeout(r, 5000));

    const manifest = [
      "source/app.py", "source/Dockerfile", "source/docker-compose.yml",
      "source/requirements.txt", "source/templates/index.html", "source/init.sql",
      "writeup/WRITEUP.md", "writeup/hints.json", "writeup/solve.py",
      "config/challenge.json", "config/dungeon_config.json", "config/anti_ai_manifest.json",
    ];

    db.challenges.create({ jobId, fileManifest: JSON.stringify(manifest), tokenUsage: 3200, generationTimeMs: 5000 });
    db.jobs.update(jobId, { status: "pending_build_review", built_at: new Date().toISOString() });
    console.log(`[Builder] ${jobId} done. Awaiting review.`);
  }, { connection, concurrency: config.queue.builderConcurrency });

  worker.on("failed", (job, err) => {
    console.error(`[Builder] ${job?.data?.jobId} failed:`, err.message);
    if (job?.data?.jobId) db.jobs.update(job.data.jobId, { status: "build_failed", error_message: err.message });
  });

  console.log("[Builder Worker] Started");
  return worker;
}

module.exports = { startBuilderWorker };
