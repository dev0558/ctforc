const { Worker } = require("bullmq");
const { connection } = require("../index");
const db = require("../../db/client");
const config = require("../../config");

const MOCK_SPEC = {
  challengeName: "Shadow Confluence",
  narrative: "A rogue admin has deployed a vulnerable Confluence instance. Exploit the OGNL injection vulnerability to extract the secret data.",
  category: "web", difficulty: "Medium", points: 300,
  cvss: { score: 9.8, vector: "NETWORK", complexity: "LOW" },
  cwe: { id: "CWE-94", name: "Code Injection" },
  mitre: { technique: "T1190", name: "Exploit Public-Facing Application" },
  techStack: ["Java", "Tomcat", "Confluence", "OGNL"],
  exploitPath: ["Discover Confluence instance", "Identify vulnerable endpoint", "Craft OGNL payload for RCE", "Extract flag from filesystem"],
  flag: "Exploit3rs{c0nflu3nc3_0gnl_pwn3d}",
  honeypotFlag: "Exploit3rs{n1c3_try_but_n0t_th3_fl4g}",
  antiAiCountermeasures: ["Prompt injection in HTML comments", "Honeypot in robots.txt", "Multi-step exploitation required"],
  reviewerNote: "CVSS 9.8, public PoC available. Medium difficulty due to OGNL knowledge requirement.",
};

function startResearcherWorker() {
  const worker = new Worker("researcher", async (job) => {
    const { jobId, cveId, ideaText, mode } = job.data;
    console.log(`[Researcher] Processing ${jobId} | ${mode === "cve" ? cveId : "idea"}`);

    db.jobs.update(jobId, { status: "researching" });
    await new Promise((r) => setTimeout(r, 3000));

    const spec = { ...MOCK_SPEC,
      challengeName: cveId ? `${cveId} Lab` : `Custom: ${(ideaText || "").substring(0, 30)}`,
    };

    db.specs.create({ jobId, specJson: JSON.stringify(spec, null, 2), tokenUsage: 1250, generationTimeMs: 3000 });
    db.jobs.update(jobId, { status: "pending_spec_review", researched_at: new Date().toISOString() });
    console.log(`[Researcher] ${jobId} done. Awaiting review.`);
  }, { connection, concurrency: config.queue.researcherConcurrency });

  worker.on("failed", (job, err) => {
    console.error(`[Researcher] ${job?.data?.jobId} failed:`, err.message);
    if (job?.data?.jobId) db.jobs.update(job.data.jobId, { status: "failed", error_message: err.message });
  });

  console.log("[Researcher Worker] Started");
  return worker;
}

module.exports = { startResearcherWorker };
