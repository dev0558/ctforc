const { Queue } = require("bullmq");
const IORedis = require("ioredis");
const config = require("../config");

// Redis connection - shared across queues
const connection = new IORedis({
  host: config.redis.host,
  port: config.redis.port,
  maxRetriesPerRequest: null, // Required by BullMQ
});

// Two separate queues: researcher and builder
const researcherQueue = new Queue("researcher", { connection });
const builderQueue = new Queue("builder", { connection });

module.exports = {
  connection,
  researcherQueue,
  builderQueue,
};
