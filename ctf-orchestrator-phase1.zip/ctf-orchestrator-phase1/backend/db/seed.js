const prisma = require("./client");

async function seed() {
  console.log("Seeding database...");

  // Create a sample batch with CVE jobs
  const batch = await prisma.batch.create({
    data: {
      mode: "cve",
      totalJobs: 3,
    },
  });

  const cves = [
    { cveId: "CVE-2023-22527", category: "web" },
    { cveId: "CVE-2024-50379", category: "web" },
    { cveId: "CVE-2025-1094", category: "web" },
  ];

  for (const cve of cves) {
    await prisma.job.create({
      data: {
        batchId: batch.id,
        cveId: cve.cveId,
        category: cve.category,
        status: "queued",
      },
    });
  }

  console.log(`Seeded batch ${batch.id} with ${cves.length} jobs`);

  // Create an idea batch
  const batch2 = await prisma.batch.create({
    data: {
      mode: "idea",
      totalJobs: 2,
    },
  });

  const ideas = [
    { ideaText: "PCAP file with DNS tunneling data exfiltration hidden in TXT records", category: "forensics", difficulty: "medium" },
    { ideaText: "RSA challenge with small public exponent vulnerable to Coppersmith attack", category: "crypto", difficulty: "hard" },
  ];

  for (const idea of ideas) {
    await prisma.job.create({
      data: {
        batchId: batch2.id,
        ideaText: idea.ideaText,
        category: idea.category,
        difficulty: idea.difficulty,
        status: "queued",
      },
    });
  }

  console.log(`Seeded batch ${batch2.id} with ${ideas.length} idea jobs`);
  console.log("Done.");
}

seed()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
