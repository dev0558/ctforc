const initSqlJs = require("sql.js");
const fs = require("fs");
const path = require("path");
const { v4: uuid } = require("uuid");

const DB_PATH = path.resolve(__dirname, "../../dev.db");
let db = null;

async function initDb() {
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    db = new SQL.Database(fs.readFileSync(DB_PATH));
  } else {
    db = new SQL.Database();
  }

  db.run(`CREATE TABLE IF NOT EXISTS batches (
    id TEXT PRIMARY KEY, mode TEXT NOT NULL, total_jobs INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY, batch_id TEXT NOT NULL, cve_id TEXT, idea_text TEXT,
    category TEXT NOT NULL DEFAULT 'web', difficulty TEXT,
    status TEXT NOT NULL DEFAULT 'queued', error_message TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    researched_at TEXT, built_at TEXT, completed_at TEXT,
    FOREIGN KEY (batch_id) REFERENCES batches(id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS specs (
    id TEXT PRIMARY KEY, job_id TEXT NOT NULL UNIQUE, spec_json TEXT NOT NULL,
    token_usage INTEGER NOT NULL DEFAULT 0, generation_time_ms INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (job_id) REFERENCES jobs(id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS challenges (
    id TEXT PRIMARY KEY, job_id TEXT NOT NULL UNIQUE, file_manifest TEXT NOT NULL,
    token_usage INTEGER NOT NULL DEFAULT 0, generation_time_ms INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (job_id) REFERENCES jobs(id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS reviews (
    id TEXT PRIMARY KEY, job_id TEXT NOT NULL, stage TEXT NOT NULL, action TEXT NOT NULL,
    notes TEXT, edited_data TEXT,
    reviewed_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (job_id) REFERENCES jobs(id)
  )`);

  save();
  console.log("[Database] SQLite initialized");
  return db;
}

function save() {
  if (!db) return;
  fs.writeFileSync(DB_PATH, Buffer.from(db.export()));
}

function all(sql, params = []) {
  const stmt = db.prepare(sql);
  if (params.length) stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

function get(sql, params = []) {
  const rows = all(sql, params);
  return rows[0] || null;
}

function run(sql, params = []) {
  db.run(sql, params);
  save();
}

// ── Batches ──
const batches = {
  create({ mode, totalJobs }) {
    const id = uuid();
    run("INSERT INTO batches (id, mode, total_jobs) VALUES (?, ?, ?)", [id, mode, totalJobs]);
    return { id, mode, total_jobs: totalJobs };
  },
  findById(id) { return get("SELECT * FROM batches WHERE id = ?", [id]); },
};

// ── Jobs ──
const jobs = {
  create({ batchId, cveId, ideaText, category, difficulty }) {
    const id = uuid();
    const now = new Date().toISOString();
    run(
      `INSERT INTO jobs (id, batch_id, cve_id, idea_text, category, difficulty, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, 'queued', ?, ?)`,
      [id, batchId, cveId || null, ideaText || null, category, difficulty || null, now, now]
    );
    return { id, batchId, cveId, ideaText, category, difficulty, status: "queued" };
  },

  findById(id) { return get("SELECT * FROM jobs WHERE id = ?", [id]); },

  findByIdFull(id) {
    const job = get("SELECT * FROM jobs WHERE id = ?", [id]);
    if (!job) return null;
    job.batch = batches.findById(job.batch_id);
    job.spec = specs.findByJobId(id);
    job.challenge = challenges.findByJobId(id);
    job.reviews = all("SELECT * FROM reviews WHERE job_id = ? ORDER BY reviewed_at DESC", [id]);
    return job;
  },

  findExisting(cveId) {
    return get("SELECT * FROM jobs WHERE cve_id = ? AND status NOT IN ('rejected','failed') LIMIT 1", [cveId]);
  },

  findMany({ status, category, batchId, limit = 50, offset = 0 } = {}) {
    let sql = "SELECT * FROM jobs WHERE 1=1";
    const p = [];
    if (status) { sql += " AND status = ?"; p.push(status); }
    if (category) { sql += " AND category = ?"; p.push(category); }
    if (batchId) { sql += " AND batch_id = ?"; p.push(batchId); }
    sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    p.push(limit, offset);
    const rows = all(sql, p);
    return rows.map((j) => {
      j.spec = get("SELECT id, token_usage, generation_time_ms FROM specs WHERE job_id = ?", [j.id]);
      j.challenge = get("SELECT id, token_usage, generation_time_ms FROM challenges WHERE job_id = ?", [j.id]);
      j.reviews = all("SELECT id, stage, action, reviewed_at FROM reviews WHERE job_id = ?", [j.id]);
      return j;
    });
  },

  count(where = {}) {
    let sql = "SELECT COUNT(*) as count FROM jobs WHERE 1=1";
    const p = [];
    if (where.status) { sql += " AND status = ?"; p.push(where.status); }
    if (where.createdAfter) { sql += " AND created_at >= ?"; p.push(where.createdAfter); }
    return get(sql, p).count;
  },

  update(id, data) {
    const sets = [];
    const p = [];
    for (const [k, v] of Object.entries(data)) {
      sets.push(`${k} = ?`);
      p.push(v);
    }
    sets.push("updated_at = ?");
    p.push(new Date().toISOString());
    p.push(id);
    run(`UPDATE jobs SET ${sets.join(", ")} WHERE id = ?`, p);
    return get("SELECT * FROM jobs WHERE id = ?", [id]);
  },

  groupByStatus() { return all("SELECT status, COUNT(*) as count FROM jobs GROUP BY status"); },
  groupByCategory() { return all("SELECT category, COUNT(*) as count FROM jobs GROUP BY category"); },
};

// ── Specs ──
const specs = {
  create({ jobId, specJson, tokenUsage, generationTimeMs }) {
    const id = uuid();
    run("INSERT INTO specs (id, job_id, spec_json, token_usage, generation_time_ms) VALUES (?, ?, ?, ?, ?)",
      [id, jobId, specJson, tokenUsage || 0, generationTimeMs || 0]);
    return { id, jobId };
  },
  findByJobId(jobId) { return get("SELECT * FROM specs WHERE job_id = ?", [jobId]); },
  updateByJobId(jobId, data) {
    const sets = []; const p = [];
    for (const [k, v] of Object.entries(data)) { sets.push(`${k} = ?`); p.push(v); }
    p.push(jobId);
    run(`UPDATE specs SET ${sets.join(", ")} WHERE job_id = ?`, p);
  },
  sumTokens() { return get("SELECT COALESCE(SUM(token_usage),0) as t FROM specs").t; },
  count() { return get("SELECT COUNT(*) as c FROM specs").c; },
};

// ── Challenges ──
const challenges = {
  create({ jobId, fileManifest, tokenUsage, generationTimeMs }) {
    const id = uuid();
    run("INSERT INTO challenges (id, job_id, file_manifest, token_usage, generation_time_ms) VALUES (?, ?, ?, ?, ?)",
      [id, jobId, fileManifest, tokenUsage || 0, generationTimeMs || 0]);
    return { id, jobId };
  },
  findByJobId(jobId) { return get("SELECT * FROM challenges WHERE job_id = ?", [jobId]); },
  sumTokens() { return get("SELECT COALESCE(SUM(token_usage),0) as t FROM challenges").t; },
  count() { return get("SELECT COUNT(*) as c FROM challenges").c; },
};

// ── Reviews ──
const reviews = {
  create({ jobId, stage, action, notes, editedData }) {
    const id = uuid();
    run("INSERT INTO reviews (id, job_id, stage, action, notes, edited_data) VALUES (?, ?, ?, ?, ?, ?)",
      [id, jobId, stage, action, notes || null, editedData || null]);
    return { id };
  },
  groupByAction() { return all("SELECT action, COUNT(*) as count FROM reviews GROUP BY action"); },
};

module.exports = { initDb, batches, jobs, specs, challenges, reviews };
