const BASE = "http://localhost:3001/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

export const api = {
  health: () => request("/health"),
  stats: () => request("/stats"),

  // Implement
  submit: (body) => request("/implement", { method: "POST", body: JSON.stringify(body) }),

  // Jobs
  listJobs: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/jobs${q ? `?${q}` : ""}`);
  },
  getJob: (id) => request(`/jobs/${id}`),

  // Specs
  getSpec: (jobId) => request(`/specs/${jobId}`),
  reviewSpec: (jobId, body) => request(`/specs/${jobId}/review`, { method: "POST", body: JSON.stringify(body) }),

  // Challenges
  getChallenge: (jobId) => request(`/challenges/${jobId}`),
  reviewChallenge: (jobId, body) => request(`/challenges/${jobId}/review`, { method: "POST", body: JSON.stringify(body) }),
};
