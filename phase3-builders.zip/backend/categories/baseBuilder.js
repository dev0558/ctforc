const fs = require("fs");
const path = require("path");
const { generateJSON } = require("../agents/claudeClient");

const PROMPTS_DIR = path.resolve(__dirname, "../agents/prompts");

/**
 * Base builder: loads category-specific prompt, injects spec data,
 * calls Claude, parses file output, and saves to storage.
 */
async function buildChallenge(approvedSpec, categoryId) {
  const promptFile = path.join(PROMPTS_DIR, `builder-${categoryId}.md`);

  if (!fs.existsSync(promptFile)) {
    throw new Error(`No builder prompt found for category: ${categoryId}. Expected: ${promptFile}`);
  }

  // Load and customize the system prompt
  let systemPrompt = fs.readFileSync(promptFile, "utf-8");

  // Inject the real flag and honeypot into the prompt
  systemPrompt = systemPrompt.replace(/\{FLAG\}/g, approvedSpec.flag || "Exploit3rs{default_flag}");
  systemPrompt = systemPrompt.replace(/\{HONEYPOT_FLAG\}/g, approvedSpec.honeypotFlag || "Exploit3rs{fake_flag}");

  // Build the user prompt from the approved spec
  const userPrompt = buildUserPrompt(approvedSpec);

  console.log(`[Builder] Calling Claude for ${categoryId} challenge: "${approvedSpec.challengeName}"...`);

  const { result, tokenUsage, durationMs } = await generateJSON({
    systemPrompt,
    userPrompt,
    maxRetries: 2,
  });

  // Validate the output has a files object
  if (!result.files || typeof result.files !== "object") {
    throw new Error("Builder output missing 'files' object");
  }

  const fileList = Object.keys(result.files);
  if (fileList.length < 3) {
    throw new Error(`Builder produced only ${fileList.length} files, expected at least 3`);
  }

  console.log(`[Builder] Generated ${fileList.length} files (${tokenUsage} tokens, ${durationMs}ms)`);

  return {
    files: result.files,        // { "source/app.py": "content...", ... }
    fileList,                    // ["source/app.py", ...]
    tokenUsage,
    durationMs,
  };
}

/**
 * Build the user prompt with all spec details so Claude has full context
 */
function buildUserPrompt(spec) {
  const sections = [
    `Build a complete CTF challenge from this approved specification:`,
    ``,
    `== CHALLENGE IDENTITY ==`,
    `Name: ${spec.challengeName}`,
    `Category: ${spec.category}`,
    `Difficulty: ${spec.difficulty}`,
    `Points: ${spec.points}`,
    ``,
    `== NARRATIVE ==`,
    spec.narrative,
    ``,
    `== TECH STACK ==`,
    (spec.techStack || []).join(", "),
    ``,
    `== VULNERABILITY ==`,
  ];

  if (spec.cwe) {
    sections.push(`CWE: ${spec.cwe.id} - ${spec.cwe.name}`);
  }
  if (spec.cvss) {
    sections.push(`CVSS: ${spec.cvss.score} (${spec.cvss.severity})`);
  }
  if (spec.mitre) {
    sections.push(`MITRE: ${spec.mitre.technique} - ${spec.mitre.name}`);
  }

  sections.push(``);
  sections.push(`== EXPLOIT PATH (the player's solution steps) ==`);
  (spec.exploitPath || []).forEach((step, i) => {
    sections.push(`${i + 1}. ${step}`);
  });

  sections.push(``);
  sections.push(`== FLAGS ==`);
  sections.push(`Real flag: ${spec.flag}`);
  sections.push(`Honeypot (decoy) flag: ${spec.honeypotFlag}`);

  sections.push(``);
  sections.push(`== ANTI-AI COUNTERMEASURES TO IMPLEMENT ==`);
  (spec.antiAiCountermeasures || []).forEach((measure) => {
    sections.push(`- ${measure}`);
  });

  if (spec.learningObjective) {
    sections.push(``);
    sections.push(`== LEARNING OBJECTIVE ==`);
    sections.push(spec.learningObjective);
  }

  if (spec.toolsRequired) {
    sections.push(``);
    sections.push(`== TOOLS PLAYERS NEED ==`);
    sections.push((spec.toolsRequired || []).join(", "));
  }

  sections.push(``);
  sections.push(`Generate ALL files as specified in your system prompt. Every file must be complete and functional.`);

  return sections.join("\n");
}

/**
 * Save generated files to the storage directory
 */
function saveFiles(jobId, files, storagePath) {
  const challengeDir = path.join(storagePath, "challenges", jobId);

  for (const [filePath, content] of Object.entries(files)) {
    const fullPath = path.join(challengeDir, filePath);
    const dir = path.dirname(fullPath);

    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(fullPath, content, "utf-8");
  }

  console.log(`[Builder] Saved ${Object.keys(files).length} files to ${challengeDir}`);
  return challengeDir;
}

module.exports = { buildChallenge, saveFiles };
