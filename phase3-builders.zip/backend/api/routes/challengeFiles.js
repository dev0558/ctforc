const { Router } = require("express");
const fs = require("fs");
const path = require("path");
const config = require("../../config");

const router = Router();

/**
 * GET /api/challenges/:jobId/files
 * Returns the actual content of all generated files for review
 */
router.get("/:jobId/files", (req, res) => {
  try {
    const challengeDir = path.join(config.storage.basePath, "challenges", req.params.jobId);

    if (!fs.existsSync(challengeDir)) {
      return res.status(404).json({ error: "Challenge files not found. Builder may still be processing." });
    }

    const files = {};
    readDirRecursive(challengeDir, challengeDir, files);

    res.json({
      jobId: req.params.jobId,
      totalFiles: Object.keys(files).length,
      files, // { "source/app.py": { content: "...", size: 1234, language: "python" }, ... }
    });
  } catch (err) {
    console.error("[ChallengeFiles] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/challenges/:jobId/files/:filepath
 * Returns a single file's content (for code viewer)
 */
router.get("/:jobId/files/*", (req, res) => {
  try {
    const filePath = req.params[0]; // everything after /files/
    const fullPath = path.join(config.storage.basePath, "challenges", req.params.jobId, filePath);

    // Security: prevent path traversal
    const resolved = path.resolve(fullPath);
    const baseDir = path.resolve(config.storage.basePath, "challenges", req.params.jobId);
    if (!resolved.startsWith(baseDir)) {
      return res.status(403).json({ error: "Path traversal not allowed" });
    }

    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: `File not found: ${filePath}` });
    }

    const content = fs.readFileSync(fullPath, "utf-8");
    const ext = path.extname(filePath).slice(1);

    res.json({
      path: filePath,
      content,
      size: Buffer.byteLength(content),
      language: detectLanguage(ext),
    });
  } catch (err) {
    console.error("[ChallengeFiles] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

function readDirRecursive(dir, baseDir, result) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relativePath = path.relative(baseDir, fullPath);
    if (entry.isDirectory()) {
      readDirRecursive(fullPath, baseDir, result);
    } else {
      const content = fs.readFileSync(fullPath, "utf-8");
      const ext = path.extname(entry.name).slice(1);
      result[relativePath] = {
        content,
        size: Buffer.byteLength(content),
        language: detectLanguage(ext),
      };
    }
  }
}

function detectLanguage(ext) {
  const map = {
    py: "python", js: "javascript", jsx: "jsx", ts: "typescript",
    c: "c", cpp: "cpp", h: "c", java: "java", rb: "ruby", php: "php",
    html: "html", css: "css", sql: "sql", sh: "bash", bash: "bash",
    yml: "yaml", yaml: "yaml", json: "json", md: "markdown",
    txt: "text", dockerfile: "dockerfile", conf: "text", cfg: "text",
    pem: "text", key: "text",
  };
  return map[ext.toLowerCase()] || "text";
}

module.exports = router;
