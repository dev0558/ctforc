const { Worker } = require("bullmq");
const { connection } = require("../index");
const db = require("../../db/client");
const config = require("../../config");
const { buildChallenge, saveFiles } = require("../../categories/baseBuilder");

function startBuilderWorker() {
  const worker = new Worker(
    "builder",
    async (job) => {
      const { jobId } = job.data;
      console.log(`[Builder Worker] Processing ${jobId}`);

      // Get the job and its approved spec
      const jobRecord = db.jobs.findById(jobId);
      if (!jobRecord) {
        throw new Error(`Job ${jobId} not found`);
      }

      const specRecord = db.specs.findByJobId(jobId);
      if (!specRecord) {
        throw new Error(`No spec found for job ${jobId}`);
      }

      // Parse the approved spec
      let approvedSpec;
      try {
        approvedSpec = typeof specRecord.spec_json === "string"
          ? JSON.parse(specRecord.spec_json)
          : specRecord.spec_json;
      } catch (err) {
        throw new Error(`Failed to parse spec JSON for job ${jobId}: ${err.message}`);
      }

      const category = approvedSpec.category || jobRecord.category || "web";
      console.log(`[Builder Worker] Category: ${category} | Challenge: "${approvedSpec.challengeName}"`);

      // Update status to building
      db.jobs.update(jobId, { status: "building" });

      try {
        // Call the real builder via Claude API
        const result = await buildChallenge(approvedSpec, category);

        // Save files to storage
        saveFiles(jobId, result.files, config.storage.basePath);

        // Save challenge record to database
        db.challenges.create({
          jobId,
          fileManifest: JSON.stringify(result.fileList),
          tokenUsage: result.tokenUsage,
          generationTimeMs: result.durationMs,
        });

        // Update job status
        db.jobs.update(jobId, {
          status: "pending_build_review",
          built_at: new Date().toISOString(),
        });

        console.log(`[Builder Worker] ${jobId} complete: ${result.fileList.length} files | ${result.tokenUsage} tokens | ${result.durationMs}ms`);
        return { jobId, status: "pending_build_review", filesCount: result.fileList.length };
      } catch (err) {
        console.error(`[Builder Worker] ${jobId} error:`, err.message);

        const currentJob = db.jobs.findById(jobId);
        const retryCount = (currentJob?.retry_count || 0) + 1;

        if (retryCount >= config.queue.builderMaxRetries) {
          db.jobs.update(jobId, {
            status: "build_failed",
            error_message: err.message,
            retry_count: retryCount,
          });
        } else {
          db.jobs.update(jobId, {
            error_message: err.message,
            retry_count: retryCount,
          });
        }

        throw err; // Let BullMQ retry
      }
    },
    {
      connection,
      concurrency: config.queue.builderConcurrency,
    }
  );

  worker.on("completed", (bullJob, result) => {
    console.log(`[Builder Worker] Job ${bullJob.id} completed: ${result?.filesCount} files`);
  });

  worker.on("failed", (bullJob, err) => {
    console.error(`[Builder Worker] Job ${bullJob?.id} failed:`, err.message);
  });

  console.log("[Builder Worker] Started (Phase 3: real Claude API builders)");
  return worker;
}

module.exports = { startBuilderWorker };
