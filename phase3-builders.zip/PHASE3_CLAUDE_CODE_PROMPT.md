# Phase 3: Category-Specific Builders — Claude Code Prompt

## CONTEXT
Phase 1 (skeleton) and Phase 2 (researcher agent) are complete. The backend runs, the researcher generates real AI-powered specs from CVEs and custom ideas, the dashboard works with the category dropdown. But the BUILDER is still a mock: it produces generic fake files that don't match the approved spec.

Phase 3 replaces the mock builder with real Claude-powered builders that generate actual challenge files tailored to each category.

## THE PROBLEM WE'RE FIXING
When CVE-2023-32784 (KeePass memory dump) was submitted:
- The researcher correctly identified it as forensics, generated "Echoes of the Vault" with a memory dump exploit path
- But the builder generated a generic PCAP script with a HARDCODED default flag instead of the spec's flag
- The writeup was generic instead of following the spec's 7-step exploit path
- Wrong artifacts for the category (PCAP for a memory dump challenge)

This happened because the builder was a mock that ignored the approved spec entirely.

## NEW FILES TO ADD

### backend/categories/baseBuilder.js
The core builder engine. Shared by ALL categories. It:
1. Loads the category-specific prompt template from `agents/prompts/builder-{category}.md`
2. Injects the real flag and honeypot flag into the prompt
3. Builds a detailed user prompt from the FULL approved spec (name, narrative, tech stack, exploit path, flags, anti-AI measures)
4. Calls Claude API via `claudeClient.generateJSON()`
5. Validates the output has a `files` object with at least 3 files
6. Saves all generated files to `storage/challenges/{jobId}/`

This means each category only needs its own prompt.md file. The builder logic is shared.

### backend/agents/prompts/builder-web.md
Web exploitation builder prompt. Tells Claude to generate: Dockerfile, Flask/Express app with REAL vulnerability, exploit script, writeup following the spec's exploit path, hints, challenge config. Enforces anti-AI countermeasures in HTML comments and HTTP headers.

### backend/agents/prompts/builder-forensics.md
Forensics builder prompt. Generates: artifact generator script (PCAP via scapy, memory dump via struct, log files), solver script, writeup with tool commands (Wireshark, Volatility, strings). Specific rules for PCAP challenges (200+ noise packets), memory dump challenges (realistic memory patterns), log analysis (multi-file correlation).

### backend/agents/prompts/builder-crypto.md
Crypto builder prompt. Generates: encryption script with real mathematical weakness, ciphertext, solver with exploit math, writeup.

### backend/agents/prompts/builder-osint.md
OSINT builder prompt. Generates: breadcrumb generator (fake profiles, EXIF images, website pages), investigation writeup, solver.

### backend/agents/prompts/builder-network.md
Network builder prompt. Generates: PCAP generator with 200+ packets of noise traffic, evidence hidden in protocol fields, solver with Wireshark filters.

### backend/agents/prompts/builder-pwn.md
Pwn builder prompt. Generates: vulnerable C source, Makefile with correct protections, Dockerfile with xinetd, pwntools exploit, binary analysis writeup.

### backend/queue/workers/builderWorker.js (REPLACE existing)
Updated worker that:
1. Reads the approved spec from the database
2. Parses the spec JSON
3. Determines the category
4. Calls `buildChallenge(approvedSpec, category)` from baseBuilder.js
5. Saves files to storage
6. Creates challenge record in database
7. Updates job status to pending_build_review

### backend/api/routes/challengeFiles.js (NEW)
New API endpoint for the dashboard to fetch actual generated file contents:
- `GET /api/challenges/:jobId/files` returns ALL file contents with language detection
- `GET /api/challenges/:jobId/files/:filepath` returns a single file
- Path traversal protection included

## YOUR TASKS

### Task 1: Install the new files
Place all new files in their correct locations. The key paths:
```
backend/
  categories/
    baseBuilder.js              ← NEW (core builder engine)
  agents/
    prompts/
      builder-web.md            ← NEW
      builder-forensics.md      ← NEW
      builder-crypto.md         ← NEW
      builder-osint.md          ← NEW
      builder-network.md        ← NEW
      builder-pwn.md            ← NEW
  queue/
    workers/
      builderWorker.js          ← REPLACE (real Claude calls)
  api/
    routes/
      challengeFiles.js         ← NEW (file content API)
```

### Task 2: Register the new route in server.js
Add this line to server.js where routes are registered:
```javascript
app.use("/api/challenges", require("./api/routes/challengeFiles"));
```
Make sure it doesn't conflict with the existing challenges route. The challengeFiles route handles `/api/challenges/:jobId/files` while the existing route handles `/api/challenges/:jobId` and `/api/challenges/:jobId/review`.

### Task 3: Create the storage directory
Make sure `storage/challenges/` exists and is writable. The builder saves generated files there.

### Task 4: Test with a web challenge
```bash
# Submit a web CVE
curl -X POST http://localhost:3001/api/implement \
  -H "Content-Type: application/json" \
  -d '{"mode":"cve","items":["CVE-2023-22527"]}'

# Wait for researcher (~30 seconds)
# Approve the spec
curl -X POST http://localhost:3001/api/specs/<JOB_ID>/review \
  -H "Content-Type: application/json" \
  -d '{"action":"approve"}'

# Wait for builder (~30-60 seconds, this is a big Claude call)

# Check the generated files
curl http://localhost:3001/api/challenges/<JOB_ID>/files | python3 -m json.tool

# Verify:
# - source/app.py contains a real Flask app with the actual OGNL injection vulnerability
# - source/Dockerfile is valid and buildable
# - The REAL flag from the spec appears in the correct location (not hardcoded default)
# - The HONEYPOT flag appears in HTML comments or robots.txt
# - writeup/WRITEUP.md follows the spec's exploit path exactly
# - writeup/solve.py is an automated solver that would work against the app
```

### Task 5: Test with a forensics challenge
```bash
curl -X POST http://localhost:3001/api/implement \
  -H "Content-Type: application/json" \
  -d '{"mode":"cve","items":["CVE-2023-32784"]}'

# After researcher + approve spec + builder:
# Verify:
# - source/generate_artifacts.py generates memory dump artifacts (NOT generic PCAP)
# - The flag from the spec is embedded using proper memory forensics techniques
# - writeup/WRITEUP.md references Volatility, memory analysis tools
# - writeup/solve.py extracts the flag from the generated artifacts
```

### Task 6: Test the file viewer API
```bash
# Get all files for a completed challenge
curl http://localhost:3001/api/challenges/<JOB_ID>/files

# Get a single file
curl http://localhost:3001/api/challenges/<JOB_ID>/files/source/app.py
```

### Task 7: Update the Build Review page
The frontend BuildReview.jsx should now use the real file content API:
- Fetch `GET /api/challenges/:jobId/files` when the page loads
- Render each file with syntax highlighting based on the language field
- Show a file tree sidebar listing all generated files
- Clicking a file shows its content in the main panel
- Keep the approve/reject buttons at the bottom

### Task 8: Test a full pipeline (both categories)
Submit one web CVE and one forensics idea simultaneously:
```bash
# Web
curl -X POST http://localhost:3001/api/implement \
  -H "Content-Type: application/json" \
  -d '{"mode":"cve","items":["CVE-2024-21887"]}'

# Forensics idea
curl -X POST http://localhost:3001/api/implement \
  -H "Content-Type: application/json" \
  -d '{"mode":"idea","items":[{"description":"Analyze a PCAP file to find DNS tunneling exfiltration of company secrets through base64-encoded TXT record queries","category":"forensics","difficulty":"medium"}]}'
```
Both should produce category-appropriate artifacts.

## CRITICAL RULES

1. The builder MUST use the flag from the approved spec. NEVER hardcode a default flag.
2. The builder MUST follow the exploit path from the approved spec. The writeup must match.
3. Each category produces DIFFERENT artifacts. Web = Docker app. Forensics = artifact generator. Crypto = encryption script. They are NOT interchangeable.
4. The baseBuilder.js handles ALL the Claude API interaction. Category-specific builders only need their prompt.md file. This is the modular pattern Ali asked for.
5. Generated files are saved to `storage/challenges/{jobId}/` on disk and their paths are stored in the database.
6. If a builder prompt doesn't exist for a category, the worker should fail gracefully with a clear error message.
7. The Claude API call for building is larger than research (generates entire files). Expect 3,000-8,000 output tokens. Set max_tokens to 8192 in claudeClient.js if not already.

## WHAT SUCCESS LOOKS LIKE
1. Submit CVE-2023-22527 (Confluence OGNL injection)
2. Researcher creates spec with web category, OGNL exploit path
3. Approve spec
4. Builder generates: real Flask app with OGNL-like vulnerability, working Dockerfile, exploit script, writeup matching the 4-step exploit path, anti-AI in HTML comments
5. The REAL flag from the spec appears in the app (accessible only through the exploit)
6. The HONEYPOT flag appears in obvious locations (HTML comments, robots.txt)
7. Dashboard Build Review page shows all generated files with syntax highlighting
8. Approve the build, job reaches "ready"
9. Same pipeline works for forensics: generates artifact scripts, not Docker apps
