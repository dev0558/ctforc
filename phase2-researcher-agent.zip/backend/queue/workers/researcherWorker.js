const { Worker } = require("bullmq");
const { connection } = require("../index");
const db = require("../../db/client");
const config = require("../../config");
const { researchCVE, researchIdea } = require("../../researcher");

function startResearcherWorker() {
  const worker = new Worker(
    "researcher",
    async (job) => {
      const { jobId, cveId, ideaText, mode } = job.data;
      const label = mode === "cve" ? cveId : `idea: "${(ideaText || "").substring(0, 40)}"`;
      console.log(`[Researcher Worker] Processing ${jobId} | ${label}`);

      // Update status to researching
      db.jobs.update(jobId, { status: "researching" });

      try {
        let result;

        if (mode === "cve" && cveId) {
          result = await researchCVE(cveId);
        } else if (mode === "idea" && ideaText) {
          const jobData = db.jobs.findById(jobId);
          result = await researchIdea(
            ideaText,
            jobData?.category || "web",
            jobData?.difficulty || "medium"
          );
        } else {
          throw new Error(`Invalid job data: mode=${mode}, cveId=${cveId}, ideaText=${ideaText}`);
        }

        // Save spec to database
        db.specs.create({
          jobId,
          specJson: JSON.stringify(result.spec, null, 2),
          tokenUsage: result.tokenUsage,
          generationTimeMs: result.durationMs,
        });

        // Update job status
        db.jobs.update(jobId, {
          status: "pending_spec_review",
          researched_at: new Date().toISOString(),
          // Update category if CVE research detected a different one
          ...(result.spec.category ? { category: result.spec.category } : {}),
        });

        console.log(`[Researcher Worker] ${jobId} complete: "${result.spec.challengeName}" | ${result.tokenUsage} tokens`);
        return { jobId, status: "pending_spec_review", challengeName: result.spec.challengeName };
      } catch (err) {
        console.error(`[Researcher Worker] ${jobId} error:`, err.message);

        // Update retry count
        const currentJob = db.jobs.findById(jobId);
        const retryCount = (currentJob?.retry_count || 0) + 1;

        if (retryCount >= config.queue.researcherMaxRetries) {
          db.jobs.update(jobId, {
            status: "failed",
            error_message: err.message,
            retry_count: retryCount,
          });
        } else {
          db.jobs.update(jobId, {
            error_message: err.message,
            retry_count: retryCount,
          });
        }

        throw err; // Let BullMQ handle retry
      }
    },
    {
      connection,
      concurrency: config.queue.researcherConcurrency,
    }
  );

  worker.on("completed", (job, result) => {
    console.log(`[Researcher Worker] Job ${job.id} completed successfully`);
  });

  worker.on("failed", (job, err) => {
    console.error(`[Researcher Worker] Job ${job?.id} failed:`, err.message);
  });

  console.log("[Researcher Worker] Started (Phase 2: real Claude API)");
  return worker;
}

module.exports = { startResearcherWorker };
