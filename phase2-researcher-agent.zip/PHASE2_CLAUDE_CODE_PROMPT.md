# Phase 2: Researcher Agent — Claude Code Prompt

## CONTEXT
We are building the CTF Challenge Orchestrator for Exploit3rs Cyber Security Academy. Phase 1 is complete: the backend skeleton works with mock workers, all API endpoints function, the sql.js database layer is operational, BullMQ queues process jobs, and the React frontend dashboard exists.

Phase 2 replaces the mock researcher worker with real AI-powered research. After this phase, submitting a CVE or custom idea will produce a real, AI-generated challenge specification.

## WHAT CHANGED IN PHASE 2
I am providing new files that implement the researcher module. These files need to be integrated into the existing project.

## NEW FILES TO ADD

### backend/agents/claudeClient.js
Claude SDK wrapper. Handles API calls with retry logic, JSON parsing, markdown fence stripping, and token tracking. Two methods:
- `generateJSON({ systemPrompt, userPrompt, maxRetries })` — returns `{ result, tokenUsage, durationMs }`
- `generateText({ systemPrompt, userPrompt })` — for plain text completions

### backend/agents/prompts/researcher-cve.md
System prompt for CVE mode. Instructs Claude to generate a structured JSON challenge spec from enriched CVE data. Defines all 15 output fields, the Exploit3rs{...} flag format, anti-AI countermeasure requirements, and the JSON schema.

### backend/agents/prompts/researcher-idea.md
System prompt for idea mode. Same output schema as CVE mode but takes a free-text description, category, and difficulty as input instead of CVE data.

### backend/researcher/nvdClient.js
NVD REST API v2.0 client. Fetches CVE data including CVSS v3.1 scores, CWE classifications, affected products (CPE), and reference URLs. Has retry logic with exponential backoff for rate limiting (403/429). Parses the NVD response into a clean structure.

### backend/researcher/refCollector.js
Categorizes CVE reference URLs into: pocs (exploit-db, GitHub PoCs), advisories (vendor security bulletins), writeups (blog posts, analysis), patches (commits, PRs), and other. Also provides `hasPublicExploit()` check.

### backend/researcher/contextEnricher.js
Enriches raw NVD data with:
- CWE to human-readable name and CTF category mapping (40+ CWEs mapped)
- MITRE ATT&CK technique mapping per category
- Tech stack detection from CPE strings (30+ technology keywords)
- Difficulty suggestion heuristic based on CVSS complexity, privileges required, user interaction, and exploit availability

### backend/researcher/schemas/challengeSpec.js
Zod schema validating all 15 spec fields. Enforces: flag format regex, point values enum, category enum, difficulty enum, minimum lengths for narrative/exploit path/anti-AI measures, and tech stack non-empty.

### backend/researcher/specGenerator.js
Orchestrates the Claude API call:
- Loads the correct prompt template (.md file) based on mode
- Builds a detailed user prompt from enriched context (CVE mode) or user description (idea mode)
- Calls `claudeClient.generateJSON()`
- Validates output against Zod schema
- Returns validated spec + token metrics

### backend/researcher/index.js
Main orchestrator that runs the full pipeline:
- CVE mode: `fetchCVE()` → `categorizeReferences()` → `enrichContext()` → `generateFromCVE()` → validated spec
- Idea mode: `generateFromIdea()` → validated spec

### backend/queue/workers/researcherWorker.js (REPLACE existing)
Updated BullMQ worker that calls the real researcher pipeline instead of the mock. Handles errors, retry counting, and status updates.

## YOUR TASKS

### Task 1: Install the Claude SDK
```bash
cd backend && npm install @anthropic-ai/sdk
```

### Task 2: Drop in the new files
Copy all the new files into their correct locations in the project. The folder structure:
```
backend/
  agents/
    claudeClient.js          ← NEW
    prompts/
      researcher-cve.md      ← NEW
      researcher-idea.md     ← NEW
  researcher/
    index.js                 ← NEW
    nvdClient.js             ← NEW
    refCollector.js          ← NEW
    contextEnricher.js       ← NEW
    specGenerator.js         ← NEW
    schemas/
      challengeSpec.js       ← NEW
  queue/
    workers/
      researcherWorker.js    ← REPLACE existing mock
```

### Task 3: Verify .env has the Claude API key
Make sure the .env file has a valid `ANTHROPIC_API_KEY`. The model should be `claude-sonnet-4-20250514`.

### Task 4: Test the full CVE pipeline
Run these tests:
```bash
# 1. Start backend
cd backend && node server.js

# 2. Submit a real CVE
curl -X POST http://localhost:3001/api/implement \
  -H "Content-Type: application/json" \
  -d '{"mode":"cve","items":["CVE-2023-22527"]}'

# 3. Wait ~30 seconds for researcher to process (NVD fetch + Claude call)

# 4. Check job status
curl http://localhost:3001/api/jobs

# 5. Get the generated spec
curl http://localhost:3001/api/specs/<JOB_ID>

# Expected: real challenge spec with name, narrative, exploit path, flags, anti-AI measures
```

### Task 5: Test the idea pipeline
```bash
curl -X POST http://localhost:3001/api/implement \
  -H "Content-Type: application/json" \
  -d '{"mode":"idea","items":[{"description":"PCAP file containing DNS tunneling data exfiltration hidden in TXT record queries to a suspicious domain","category":"forensics","difficulty":"medium"}]}'
```

### Task 6: Test validation and error handling
- Submit an invalid CVE ID (e.g., "NOT-A-CVE") — should get 400 validation error
- Submit a CVE that doesn't exist in NVD (e.g., "CVE-9999-99999") — should fail gracefully, job status becomes "failed"
- Verify retry logic works: if Claude returns invalid JSON on first attempt, the worker retries with a correction hint

### Task 7: Test the full approve flow
1. Submit CVE, wait for pending_spec_review
2. GET /api/specs/:jobId — verify spec has all 15 fields
3. POST /api/specs/:jobId/review with {"action":"approve"} — job should move to spec_approved, then building (mock builder still runs)
4. Wait for pending_build_review
5. POST /api/challenges/:jobId/review with {"action":"approve"} — job reaches "ready"

### Task 8: Verify dashboard shows real specs
Open the frontend dashboard. Submit a CVE. When the job reaches pending_spec_review, the spec review page should show the real AI-generated challenge name, narrative, difficulty, tech stack, exploit path, flags, and anti-AI countermeasures instead of mock data.

### Task 9: Test a batch of 3 CVEs
```bash
curl -X POST http://localhost:3001/api/implement \
  -H "Content-Type: application/json" \
  -d '{"mode":"cve","items":["CVE-2023-22527","CVE-2024-50379","CVE-2024-21887"]}'
```
All 3 should process with concurrency 2 (two research simultaneously, third waits). Each should produce a unique, well-formed spec.

## IMPORTANT NOTES

- The NVD API is public but rate-limited. If you get 403/429, the retry logic handles it automatically. Don't spam requests.
- The Claude API key MUST be set in .env. Without it, all research jobs will fail.
- The builder worker is STILL a mock (Phase 3 replaces it). After spec approval, the mock builder runs for 5 seconds and produces fake file manifests. This is expected.
- Prompt templates are .md files in agents/prompts/. If spec quality is bad, edit the prompt file — no code changes needed.
- The Zod schema enforces Exploit3rs{...} flag format. If Claude generates a different format, the validation catches it and triggers a retry.
- Token usage is tracked per spec. Check GET /api/stats to see total tokens and estimated cost.
- The NVD client uses Node's native fetch (available in Node 18+). No axios needed.

## WHAT SUCCESS LOOKS LIKE
1. Submit "CVE-2023-22527" via API or dashboard
2. Job transitions: queued → researching → pending_spec_review (takes 15-60 seconds)
3. Spec contains a real, creative challenge name (NOT "CVE-2023-22527 Lab")
4. Spec has a compelling narrative, correct tech stack (Java, Tomcat, Confluence, OGNL), proper exploit path
5. Flag matches Exploit3rs{...} format
6. Anti-AI countermeasures are specific to web/OGNL injection, not generic
7. Reviewer note explains the difficulty choice
8. Stats show real token usage and cost estimate
9. Submit a forensics idea — spec is generated with forensics-appropriate artifacts and countermeasures
10. Batch of 3 CVEs all process successfully with unique specs
